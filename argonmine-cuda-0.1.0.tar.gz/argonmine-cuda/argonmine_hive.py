#!/usr/bin/env python3
"""Argonmine multi-GPU driver for HiveOS.

One work fetcher for the whole rig (the public work API is rate-limited per IP),
one argon_gpu process per GPU, each with its own nonce seed so no two cards
hash the same nonces. Hits from any card are submitted with the rig's address.
Writes stats.json for h-stats.sh.

Based on driver/gpumine.py from github.com/YGYxop6/argonmine-cuda-miner (MIT).
"""
import argparse
import ctypes
import json
import os
import re
import signal
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
RATE_RE = re.compile(r"->\s*([0-9.]+)\s*H/s")
LOCK = threading.Lock()
STATE = {"hs": {}, "accepted": 0, "rejected": 0, "start": time.time()}
CHILDREN = []


def log(msg):
    print(time.strftime("%H:%M:%S ") + msg, flush=True)


def http_json(url, data=None, timeout=20):
    req = urllib.request.Request(url, method="POST" if data is not None else "GET")
    body = None
    if data is not None:
        body = json.dumps(data).encode()
        req.add_header("Content-Type", "application/json")
    with urllib.request.urlopen(req, body, timeout=timeout) as r:
        return json.loads(r.read().decode())


def gpu_inventory():
    """[(index, bus_number, total_MiB, name)] from nvidia-smi."""
    out = subprocess.run(
        ["nvidia-smi", "--query-gpu=index,pci.bus_id,memory.total,name", "--format=csv,noheader,nounits"],
        capture_output=True, text=True, check=True).stdout
    gpus = []
    for line in out.strip().splitlines():
        idx, bus, mem, name = [x.strip() for x in line.split(",", 3)]
        bus_num = int(bus.split(":")[-2], 16)          # 00000000:0A:00.0 -> 10
        gpus.append((int(idx), bus_num, int(float(mem)), name))
    return gpus


def gpu_sensors():
    try:
        out = subprocess.run(
            ["nvidia-smi", "--query-gpu=index,temperature.gpu,fan.speed", "--format=csv,noheader,nounits"],
            capture_output=True, text=True, timeout=10).stdout
        res = {}
        for line in out.strip().splitlines():
            i, t, f = [x.strip() for x in line.split(",")]
            res[int(i)] = (int(t) if t.isdigit() else 0, int(f) if f.isdigit() else 0)
        return res
    except Exception:                                               # noqa: BLE001
        return {}


def auto_batch(total_mib):
    # each hash in flight needs 8 MiB; keep >= 1.5 GiB headroom, multiple of 128, max 1024
    b = int((total_mib - 1536) // 8) // 128 * 128
    return max(128, min(1024, b))


def die_with_parent():
    try:
        ctypes.CDLL("libc.so.6").prctl(1, signal.SIGTERM)   # PR_SET_PDEATHSIG
    except Exception:                                               # noqa: BLE001
        pass


def submit(args, gpu, job_id, nonce):
    log(f"*** GPU{gpu} hit job={job_id} nonce={nonce}")
    try:
        res = http_json(args.api + "/api/work/submit",
                        {"job_id": job_id, "nonce": nonce, "address": args.address})
    except Exception as e:                                          # noqa: BLE001
        log(f"[submit] GPU{gpu} error {e}")
        with LOCK:
            STATE["rejected"] += 1
        return
    with LOCK:
        if res.get("accepted"):
            STATE["accepted"] += 1
            log(f"*** BLOCK ACCEPTED *** GPU{gpu} hash={res.get('hash')}")
        else:
            STATE["rejected"] += 1
            log(f"[submit] GPU{gpu} {res}")


def run_gpu(args, gpu, batch):
    env = dict(os.environ, CUDA_VISIBLE_DEVICES=str(gpu))
    cmd = [args.bin, "--jobfile", args.jobfile, "--batch", str(batch),
           "--seconds", "0", "--nonce-seed", str(gpu + 1)]
    while True:
        log(f"[GPU{gpu}] start batch={batch}")
        proc = subprocess.Popen(cmd, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                text=True, bufsize=1, preexec_fn=die_with_parent)
        CHILDREN.append(proc)
        last_print = 0.0
        for line in proc.stdout:
            line = line.rstrip()
            m = RATE_RE.search(line)
            if m:
                with LOCK:
                    STATE["hs"][gpu] = float(m.group(1))
                if time.time() - last_print > 30:
                    last_print = time.time()
                    log(f"[GPU{gpu}] {float(m.group(1)):,.0f} H/s")
                continue
            if line.startswith("HIT "):
                parts = line.split()
                if len(parts) == 3 and parts[2].isdigit():
                    threading.Thread(target=submit, args=(args, gpu, parts[1], int(parts[2])), daemon=True).start()
                else:
                    log(f"[GPU{gpu}] malformed hit line ignored: {line}")
                continue
            log(f"[GPU{gpu}] {line}")
        proc.wait()
        with LOCK:
            STATE["hs"][gpu] = 0.0
        log(f"[GPU{gpu}] exited rc={proc.returncode}, restart in 5 s")
        time.sleep(5)


def write_job(path, job):
    tmp = path + ".tmp"
    with open(tmp, "w") as f:
        f.write(job["job_id"] + "\n" + job["header_prefix"] + "\n" + job["target"] + "\n")
    os.replace(tmp, path)


def stats_loop(args, gpus):
    while True:
        sens = gpu_sensors()
        with LOCK:
            hs = [round(STATE["hs"].get(i, 0.0), 1) for i, _, _, _ in gpus]
            st = {
                "hs": hs, "hs_units": "hs",
                "temp": [sens.get(i, (0, 0))[0] for i, _, _, _ in gpus],
                "fan": [sens.get(i, (0, 0))[1] for i, _, _, _ in gpus],
                "bus_numbers": [b for _, b, _, _ in gpus],
                "uptime": int(time.time() - STATE["start"]),
                "ar": [STATE["accepted"], STATE["rejected"]],
                "algo": "argon2id", "ver": args.version,
            }
        tmp = args.stats + ".tmp"
        with open(tmp, "w") as f:
            json.dump(st, f)
        os.replace(tmp, args.stats)
        time.sleep(10)


def shutdown(*_):
    for p in CHILDREN:
        try:
            p.terminate()
        except Exception:                                           # noqa: BLE001
            pass
    sys.exit(0)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--address", required=True)
    ap.add_argument("--api", default="https://explorer.argonmine.com")
    ap.add_argument("--bin", default=os.path.join(HERE, "bin", "argon_gpu"))
    ap.add_argument("--jobfile", default="/run/argonmine_job.txt")
    ap.add_argument("--stats", default="/run/argonmine_stats.json")
    ap.add_argument("--batch", default="auto", help="auto, or one number for every GPU")
    ap.add_argument("--devices", default="all", help="all, or a list like 0,1,3")
    ap.add_argument("--interval", type=float, default=2.0)
    ap.add_argument("--version", default="0.1.0")
    args = ap.parse_args()

    if not re.fullmatch(r"arg1[0-9a-z]{20,100}", args.address):
        log(f"[config] '{args.address}' does not look like an ARG address (arg1...). Set it as the flight sheet wallet.")
        time.sleep(30)
        return 1
    args.api = args.api.rstrip("/")
    signal.signal(signal.SIGTERM, shutdown)
    signal.signal(signal.SIGINT, shutdown)
    signal.signal(signal.SIGHUP, shutdown)

    gpus = gpu_inventory()
    if args.devices != "all":
        want = {int(x) for x in args.devices.split(",") if x.strip()}
        gpus = [g for g in gpus if g[0] in want]
    if not gpus:
        log("[config] no GPU selected")
        return 1
    for idx, bus, mem, name in gpus:
        batch = auto_batch(mem) if args.batch == "auto" else int(args.batch)
        log(f"GPU{idx} {name} {mem} MiB bus {bus:02x} -> batch {batch} ({batch * 8 / 1024:.1f} GiB)")
        threading.Thread(target=run_gpu, args=(args, idx, batch), daemon=True).start()
    threading.Thread(target=stats_loop, args=(args, gpus), daemon=True).start()
    log(f"mining to {args.address} via {args.api}")

    last_height, last_fetch, backoff = None, 0.0, args.interval
    while True:
        now = time.time()
        height = None
        try:
            height = http_json(args.api + "/api/health", timeout=10).get("indexedHeight")
        except Exception:                                           # noqa: BLE001
            pass
        if height != last_height or now - last_fetch > 30:
            try:
                job = http_json(args.api + "/api/work?address=" + urllib.parse.quote(args.address))
                if job.get("header_prefix"):
                    write_job(args.jobfile, job)
                    last_height, last_fetch, backoff = height, now, args.interval
                    log(f"[job] height={job.get('height')} target={job['target'][:12]}")
                else:
                    log(f"[work] {job}")
            except urllib.error.HTTPError as e:
                if e.code == 429:
                    backoff = min(backoff * 2, 60)
                    log(f"[work] rate-limited, waiting {backoff:.0f} s")
                    time.sleep(backoff)
                else:
                    log(f"[work] HTTP {e.code}")
            except Exception as e:                                  # noqa: BLE001
                log(f"[work] fetch failed: {e}")
        time.sleep(args.interval)


if __name__ == "__main__":
    sys.exit(main())
