#!/usr/bin/env bash
# Compiles src/argon_gpu.cu into bin/argon_gpu for RTX 30 (sm_86), 40 (sm_89) and 50 (sm_120).
# Order: nvcc already on the rig -> NVIDIA's CUDA 12.8+ pip wheels (~150 MB, nothing touched outside this folder).
set -e
cd "$(dirname "$0")"
mkdir -p bin
ARCHS="-gencode arch=compute_86,code=sm_86 -gencode arch=compute_89,code=sm_89 -gencode arch=compute_120,code=sm_120 -gencode arch=compute_120,code=compute_120"

if command -v nvcc >/dev/null && nvcc --version | grep -qE 'release 12\.(8|9)|release 1[3-9]'; then
  echo "[build] using system nvcc"
  nvcc -O3 $ARCHS -o bin/argon_gpu src/argon_gpu.cu
  exit 0
fi

echo "[build] installing CUDA compiler wheels into $PWD/cuda"
command -v g++ >/dev/null || { apt-get update && apt-get install -y build-essential; }
python3 -m pip --version >/dev/null 2>&1 || { apt-get update && apt-get install -y python3-pip; }
python3 -m pip install --quiet --target cuda "nvidia-cuda-nvcc-cu12>=12.8" "nvidia-cuda-runtime-cu12>=12.8"
NV=cuda/nvidia
ln -sf libcudart.so.12 $NV/cuda_runtime/lib/libcudart.so
export PATH="$PWD/$NV/cuda_nvcc/bin:$PATH"
nvcc -O3 $ARCHS --cudart shared \
  -I $NV/cuda_runtime/include -I $NV/cuda_nvcc/include \
  -L $NV/cuda_runtime/lib -Xlinker -rpath -Xlinker "$PWD/$NV/cuda_runtime/lib" \
  -o bin/argon_gpu src/argon_gpu.cu
echo "[build] ok: bin/argon_gpu"
