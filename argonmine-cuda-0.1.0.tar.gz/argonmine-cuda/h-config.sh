#!/usr/bin/env bash
# Flight sheet -> miner.conf
#   Wallet template : %WAL%            (your arg1... address)
#   Pool URL        : https://explorer.argonmine.com   (or your own node's explorer)
#   Extra config    : optional, e.g.  batch=768 devices=0,1
cd "$(dirname "$0")"
. h-manifest.conf
ADDRESS=$(echo "$CUSTOM_TEMPLATE" | tr -d '[:space:]')
API=$(echo "$CUSTOM_URL" | tr -d '[:space:]')
[[ -z $API || $API == stratum* ]] && API=https://explorer.argonmine.com
BATCH=auto; DEVICES=all
for kv in $CUSTOM_USER_CONFIG; do
  case $kv in
    batch=*)   BATCH=${kv#batch=} ;;
    devices=*) DEVICES=${kv#devices=} ;;
  esac
done
cat > "$CUSTOM_CONFIG_FILENAME" <<CONF
ADDRESS=$ADDRESS
API=$API
BATCH=$BATCH
DEVICES=$DEVICES
CONF
