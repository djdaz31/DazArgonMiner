#!/usr/bin/env bash
cd "$(dirname "$0")"
. h-manifest.conf
[[ -f $CUSTOM_CONFIG_FILENAME ]] || ./h-config.sh
. "$CUSTOM_CONFIG_FILENAME"
mkdir -p "$(dirname "$CUSTOM_LOG_BASENAME")"
if [[ ! -x bin/argon_gpu ]]; then
  ./build.sh 2>&1 | tee -a "${CUSTOM_LOG_BASENAME}.log" || { echo "build failed, see log"; sleep 60; exit 1; }
fi
[[ -d cuda/nvidia/cuda_runtime/lib ]] && export LD_LIBRARY_PATH="$PWD/cuda/nvidia/cuda_runtime/lib:$LD_LIBRARY_PATH"
exec python3 -u argonmine_hive.py --address "$ADDRESS" --api "$API" --batch "$BATCH" \
  --devices "$DEVICES" --version "$CUSTOM_VERSION" 2>&1 | tee -a "${CUSTOM_LOG_BASENAME}.log"
