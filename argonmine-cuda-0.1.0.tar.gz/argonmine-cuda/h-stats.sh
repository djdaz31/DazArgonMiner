#!/usr/bin/env bash
# Sourced by the Hive agent: must set $khs (total kH/s) and $stats (JSON).
STATS_FILE=/run/argonmine_stats.json
if [[ -f $STATS_FILE && $(( $(date +%s) - $(stat -c %Y $STATS_FILE) )) -lt 60 ]]; then
  stats=$(cat $STATS_FILE)
  khs=$(echo "$stats" | jq '[.hs[]] | add / 1000')
else
  stats=""; khs=0
fi
[[ -z $khs ]] && khs=0
