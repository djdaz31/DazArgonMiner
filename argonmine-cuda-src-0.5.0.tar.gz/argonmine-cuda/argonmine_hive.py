#!/usr/bin/env python3
"""Argonmine multi-GPU driver (HiveOS, Ubuntu, WSL2).

One work fetcher for the whole rig (the public work API is rate-limited per IP),
one argon_gpu process per GPU, each with its own nonce seed so no two cards
hash the same nonces. Hits from any card are submitted with the rig's address.

Console: a status line every 10 s, a "GPU summary 60s avg" table every 60 s,
and a "Blocks found" section. Every accepted block is kept in blocks.json, so
the history survives restarts. Writes stats.json for HiveOS's h-stats.sh.

Based on driver/gpumine.py from github.com/YGYxop6/argonmine-cuda-miner (MIT).
"""
import argparse
import collections
import ctypes
import json
import os
import re
import signal
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
RATE_RE = re.compile(r"->\s*([0-9.]+)\s*H/s")
BLOCK_REWARD = 50
MATURITY = 100

# ---- dev fee (time based) ------------------------------------------------------------
# DEV_FEE_PCT % of mining time sends its work to DEV_ADDRESS: 1 % = 60 s every 100 min.
# Shown at start-up and in the console while active. Set DEV_FEE_PCT = 0 to turn it off.
DEV_ADDRESS = "arg1q56234qn7f2mym8sjj7m4uww2aghgh8pah4q6gnnpusrutfqkn45shvc7tz"
DEV_FEE_PCT = 1.0
DEV_CYCLE = 6000            # seconds
DEV_OFFSET = 1800           # first dev window 30 min after start (after batch tuning)
LOCK = threading.Lock()
STATE = {
    "start": time.time(),
    "samples": {},        # gpu -> deque[(t, H/s)]
    "acc": {}, "rej": {}, # gpu -> count (this session)
    "sens": {},           # gpu -> dict(power, temp, core, mem, fan)
    "height": None,       # current job height
    "jobs": collections.OrderedDict(),   # job_id -> (height, payout address)
    "dev": False,         # dev-fee window active
    "blocks": [],         # all accepted blocks, persisted
}
CHILDREN = []
STOPPING = threading.Event()
TUNE = {"total": 0, "done": 0}

# ------------------------------------------------------------------ colours
USE_COLOR = not os.environ.get("NO_COLOR")
C = {"r": "31", "g": "32", "y": "33", "b": "34", "m": "35", "c": "36", "w": "37",
     "dim": "2", "bold": "1", "bg": "1;32", "by": "1;33", "bc": "1;36", "bm": "1;35", "br": "1;31", "bb": "1;34"}


def col(text, c):
    if not USE_COLOR:
        return str(text)
    return f"\033[{C[c]}m{text}\033[0m"


VIS_RE = re.compile(r"\033\[[0-9;]*m")


def vlen(s):
    return len(VIS_RE.sub("", s))


def pad(s, w, right=True):
    n = w - vlen(s)
    return (" " * n + s) if right else (s + " " * n)


OUT_LOCK = threading.Lock()
LOGFILE = None                           # --log: plain copy of every printed line (HiveOS miner log)
IS_TTY = sys.stdout.isatty()
LIVE = collections.OrderedDict()         # key -> text, redrawn at the bottom of a terminal
LIVE_SHOWN = [0]


def _live_clear():
    if LIVE_SHOWN[0]:
        sys.stdout.write("\033[%dF\033[J" % LIVE_SHOWN[0])     # cursor up n lines, clear to end
        LIVE_SHOWN[0] = 0


def _live_draw():
    for key in sorted(LIVE):
        sys.stdout.write(LIVE[key] + "\n")
    LIVE_SHOWN[0] = len(LIVE)


def out(msg=""):
    with OUT_LOCK:                       # one write per line: threads never interleave
        _live_clear()
        sys.stdout.write(msg + "\n")
        _live_draw()
        sys.stdout.flush()
        if LOGFILE:
            try:
                LOGFILE.write(msg + "\n")
                LOGFILE.flush()
            except Exception:                                       # noqa: BLE001
                pass


def live_set(key, text):
    """Update a progress line. Only on a real terminal; logs never see cursor codes."""
    if not (IS_TTY and USE_COLOR):
        return
    with OUT_LOCK:
        _live_clear()
        LIVE[key] = text
        _live_draw()
        sys.stdout.flush()


def live_del(*keys):
    if not (IS_TTY and USE_COLOR):
        return
    with OUT_LOCK:
        _live_clear()
        for k in keys:
            LIVE.pop(k, None)
        _live_draw()
        sys.stdout.flush()


def log(msg):
    out(col(time.strftime("%H:%M:%S "), "dim") + msg)


GLYPHS = {
    "D": ["████ ", "█   █", "█   █", "█   █", "████ "],
    "A": [" ███ ", "█   █", "█████", "█   █", "█   █"],
    "Z": ["█████", "   █ ", "  █  ", " █   ", "█████"],
    "R": ["████ ", "█   █", "████ ", "█  █ ", "█   █"],
    "G": [" ████", "█    ", "█  ██", "█   █", " ████"],
    "O": [" ███ ", "█   █", "█   █", "█   █", " ███ "],
    "N": ["█   █", "██  █", "█ █ █", "█  ██", "█   █"],
    " ": ["  ", "  ", "  ", "  ", "  "],
}
SPIN = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"


def block_text(text):
    rows = ["", "", "", "", ""]
    for ch in text:
        for i, part in enumerate(GLYPHS[ch]):
            rows[i] += part + " "
    return rows


def fmt_rate(hs):
    for unit, div in (("MH/s", 1e6), ("kH/s", 1e3)):
        if hs >= div:
            return f"{hs / div:.2f} {unit}"
    return f"{hs:.0f} H/s"


def fmt_dur(sec):
    sec = int(sec)
    d, sec = divmod(sec, 86400)
    h, sec = divmod(sec, 3600)
    m, _ = divmod(sec, 60)
    return (f"{d}d " if d else "") + f"{h:02d}h{m:02d}"


# ------------------------------------------------------------------ helpers
def http_json(url, data=None, timeout=20):
    req = urllib.request.Request(url, method="POST" if data is not None else "GET")
    body = None
    if data is not None:
        body = json.dumps(data).encode()
        req.add_header("Content-Type", "application/json")
    with urllib.request.urlopen(req, body, timeout=timeout) as r:
        return json.loads(r.read().decode())


def gpu_inventory():
    """[(index, bus_number, total_MiB, name)] from nvidia-smi."""
    res = subprocess.run(
        ["nvidia-smi", "--query-gpu=index,pci.bus_id,memory.total,name", "--format=csv,noheader,nounits"],
        capture_output=True, text=True, check=True).stdout
    gpus = []
    for line in res.strip().splitlines():
        idx, bus, mem, name = [x.strip() for x in line.split(",", 3)]
        bus_num = int(bus.split(":")[-2], 16)          # 00000000:0A:00.0 -> 10
        gpus.append((int(idx), bus_num, int(float(mem)), name))
    return gpus


def gpu_arch():
    try:
        res = subprocess.run(["nvidia-smi", "--query-gpu=index,compute_cap", "--format=csv,noheader"],
                             capture_output=True, text=True, timeout=10).stdout
        arch = {}
        for line in res.strip().splitlines():
            i, cc = [x.strip() for x in line.split(",")]
            if i.isdigit() and re.fullmatch(r"\d+\.\d+", cc):
                arch[int(i)] = "sm_" + cc.replace(".", "")
        return arch
    except Exception:                                               # noqa: BLE001
        return {}


def num(x):
    try:
        return float(x)
    except ValueError:
        return 0.0


def read_sensors():
    try:
        res = subprocess.run(
            ["nvidia-smi", "--query-gpu=index,power.draw,temperature.gpu,clocks.sm,clocks.mem,fan.speed",
             "--format=csv,noheader,nounits"], capture_output=True, text=True, timeout=10).stdout
    except Exception:                                               # noqa: BLE001
        return
    sens = {}
    for line in res.strip().splitlines():
        p = [x.strip() for x in line.split(",")]
        if len(p) == 6 and p[0].isdigit():
            sens[int(p[0])] = {"power": num(p[1]), "temp": int(num(p[2])), "core": int(num(p[3])),
                               "mem": int(num(p[4])), "fan": int(num(p[5]))}
    with LOCK:
        STATE["sens"] = sens


def avg_rate(gpu, window=60):
    now = time.time()
    s = [h for t, h in STATE["samples"].get(gpu, ()) if now - t <= window]
    return sum(s) / len(s) if s else 0.0


def short_name(name):
    return name.replace("NVIDIA ", "").replace("GeForce ", "")


def auto_batch(total_mib):
    # each hash in flight needs 8 MiB; keep >= 1.5 GiB headroom, multiple of 128.
    # 1280 measured best on a 16 GB RTX 5080 with the fast kernel.
    b = int((total_mib - 1536) // 8) // 128 * 128
    cap = 1280 if total_mib >= 15000 else 1024
    return max(128, min(cap, b))


def die_with_parent():
    try:
        ctypes.CDLL("libc.so.6").prctl(1, signal.SIGTERM)   # PR_SET_PDEATHSIG
    except Exception:                                               # noqa: BLE001
        pass


def dev_active(args, now):
    if DEV_FEE_PCT <= 0 or args.address == DEV_ADDRESS:
        return False
    run = now - STATE["start"] - DEV_OFFSET
    return run >= 0 and (run % DEV_CYCLE) < DEV_CYCLE * DEV_FEE_PCT / 100.0


def load_json(path, default):
    try:
        with open(path) as f:
            return json.load(f)
    except Exception:                                               # noqa: BLE001
        return default


def save_json(path, data):
    try:
        tmp = path + ".tmp"
        with open(tmp, "w") as f:
            json.dump(data, f, indent=1)
        os.replace(tmp, path)
    except Exception as e:                                          # noqa: BLE001
        log(col(f"cannot write {path}: {e}", "y"))


def tune_candidates(total_mib):
    """Largest batches that fit with >= 1.5 GiB headroom, at most 4 of them."""
    c = [b for b in (512, 640, 768, 1024, 1280, 1536) if b * 8 + 1536 <= total_mib]
    return c[-4:] or [128]


# ------------------------------------------------------------------ blocks
def load_blocks(path):
    try:
        with open(path) as f:
            data = json.load(f)
        return data if isinstance(data, list) else []
    except Exception:                                               # noqa: BLE001
        return []


def save_blocks(path, blocks):
    try:
        tmp = path + ".tmp"
        with open(tmp, "w") as f:
            json.dump(blocks, f, indent=1)
        os.replace(tmp, path)
    except Exception as e:                                          # noqa: BLE001
        log(col(f"[blocks] cannot write {path}: {e}", "y"))


def block_banner(b):
    w = 62
    line = "═" * w
    rows = [
        f"★  BLOCK FOUND  ★   height {b['height'] if b['height'] is not None else '?'}   GPU[{b['gpu']}]",
        f"hash   {b['hash'][:48] if b['hash'] else '?'}",
        f"reward +{BLOCK_REWARD} ARG  (spendable after {MATURITY} confirmations)",
        f"total  {len(STATE['blocks'])} block(s) found with this address on this miner",
    ]
    out()
    out(col("╔" + line + "╗", "bg"))
    for r in rows:
        out(col("║ ", "bg") + col(pad(r, w - 2, right=False), "bg") + col(" ║", "bg"))
    out(col("╚" + line + "╝", "bg"))
    out()


def submit(args, gpu, job_id, nonce):
    with LOCK:
        height, payout = STATE["jobs"].get(job_id, (None, args.address))
    is_dev = payout != args.address
    log(col(f"Solution found by GPU[{gpu}]", "by") + f" job={job_id[:12]} nonce={nonce}"
        + (col(" (dev fee window)", "dim") if is_dev else "") + ", submitting...")
    try:
        res = http_json(args.api + "/api/work/submit",
                        {"job_id": job_id, "nonce": nonce, "address": payout})
    except Exception as e:                                          # noqa: BLE001
        with LOCK:
            STATE["rej"][gpu] = STATE["rej"].get(gpu, 0) + 1
        log(col(f"Block rejected (submit error: {e})", "br"))
        return
    if res.get("accepted") and is_dev:
        log(col(f"Dev fee block accepted (height {height}) - thanks for supporting the miner", "c"))
        return
    if res.get("accepted"):
        b = {"time": time.strftime("%Y-%m-%d %H:%M:%S"), "height": height, "hash": res.get("hash") or "",
             "gpu": gpu, "nonce": nonce}
        with LOCK:
            STATE["acc"][gpu] = STATE["acc"].get(gpu, 0) + 1
            STATE["blocks"].append(b)
            blocks = list(STATE["blocks"])
        save_blocks(args.blocks, blocks)
        block_banner(b)
    else:
        with LOCK:
            STATE["rej"][gpu] = STATE["rej"].get(gpu, 0) + 1
        if res.get("stale"):
            log(col(f"Block stale [GPU[{gpu}]]: someone else found this height first", "y"))
        else:
            reason = res.get("reason") or res.get("error") or res
            log(col(f"Block rejected [GPU[{gpu}]]: {reason}", "br") +
                col("  (repeated rejects = lower the memory OC)", "dim"))


# ------------------------------------------------------------------ display
def status_line(gpus):
    with LOCK:
        tot = sum(avg_rate(i, 10) for i, *_ in gpus)
        a, r = sum(STATE["acc"].values()), sum(STATE["rej"].values())
        parts = [f"GPU[{i}] {fmt_rate(avg_rate(i, 10))}" for i, *_ in gpus]
    line = (col(fmt_rate(tot), "bg") + " | " + col(f"A:{a}", "c") + " " + col(f"R:{r}", "r" if r else "c")
            + " | " + " | ".join(parts) + " | " + col(STATE.get("host", ""), "r")
            + (col("  [dev fee]", "dim") if STATE["dev"] else ""))
    out(line)


def summary(gpus, args):
    with LOCK:
        rows = []
        for idx, _, _, name in gpus:
            hs = avg_rate(idx)
            s = STATE["sens"].get(idx, {})
            pw = s.get("power", 0.0)
            rows.append((idx, short_name(name), hs, pw, hs / pw if pw else 0.0, s.get("temp", 0),
                         s.get("core", 0), s.get("mem", 0), STATE["acc"].get(idx, 0), STATE["rej"].get(idx, 0)))
        blocks = list(STATE["blocks"])
        height = STATE["height"]
        uptime = time.time() - STATE["start"]
        session = sum(STATE["acc"].values())

    hdr = (pad(col("#", "c"), 4) + "  " + pad(col("GPU", "c"), 16, False) + pad(col("H/s", "c"), 13)
           + pad(col("W", "c"), 8) + pad(col("H/s/W", "c"), 9) + pad(col("Temp", "c"), 6)
           + pad(col("Core", "c"), 7) + pad(col("Mem", "c"), 7) + pad(col("Blocks", "c"), 9))
    sep = col("─" * 79, "dim")
    out()
    out(col("GPU summary", "bold") + col("  60s avg", "dim") + col(f"   uptime {fmt_dur(uptime)}"
        + (f"   height {height}" if height is not None else ""), "dim"))
    out(hdr)
    out(sep)
    T = [0.0, 0.0, 0, 0]
    for idx, name, hs, pw, eff, temp, core, mem, a, r in rows:
        tcol = "g" if temp < 70 else ("y" if temp < 80 else "r")
        out(pad(col(idx, "m"), 4) + "  " + pad(name[:15], 16, False) + pad(col(fmt_rate(hs), "g"), 13)
            + pad(f"{pw:.1f}", 8) + pad(col(f"{eff:.1f}", "b"), 9) + pad(col(temp, tcol), 6)
            + pad(str(core), 7) + pad(str(mem), 7) + pad(col(a, "g") + "/" + col(r, "r" if r else "g"), 9))
        T[0] += hs; T[1] += pw; T[2] += a; T[3] += r
    out(sep)
    out(pad("ALL", 4) + "  " + pad(f"{len(rows)} GPU", 16, False) + pad(col(fmt_rate(T[0]), "bg"), 13)
        + pad(f"{T[1]:.1f}", 8) + pad(col(f"{(T[0] / T[1]) if T[1] else 0:.1f}", "b"), 9)
        + pad("-", 6) + pad("-", 7) + pad("-", 7)
        + pad(col(T[2], "g") + "/" + col(T[3], "r" if T[3] else "g"), 9))

    # blocks found
    out()
    total = len(blocks)
    title = col("Blocks found", "bold") + "  " + (col(f"{total} total", "bg" if total else "y")
                                                  + col(f"  ({session} this session)", "dim"))
    if total:
        title += col(f"   ≈ {total * BLOCK_REWARD} ARG", "g")
    out(title)
    if not total:
        out(col("  none yet - solo mining: you get the whole block (50 ARG) or nothing, be patient", "dim"))
    else:
        for b in blocks[-5:][::-1]:
            h = b.get("height")
            conf = ""
            if h is not None and height is not None:
                c = max(0, height - h)
                conf = col(f"  {min(c, MATURITY)}/{MATURITY} conf", "g" if c >= MATURITY else "y")
            out(f"  {col(b.get('time', '?'), 'dim')}  height {col(h if h is not None else '?', 'm')}"
                f"  GPU[{b.get('gpu', '?')}]  {col((b.get('hash') or '?')[:16] + '…', 'c')}{conf}")
        if total > 5:
            out(col(f"  … {total - 5} older, see {args.blocks}", "dim"))
    out(col(f"  explorer: {args.api}  (search your address to confirm)", "dim"))
    out()


def print_banner(args, gpus):
    W = 66
    line = col("─" * W, "r")
    out()
    for row, c in zip(block_text("DAZ ARGON"), ("bc", "bc", "c", "bb", "b")):
        out("   " + col(row, c))
    out(col("   Argon2id GPU miner  ·  solo  ·  RTX 30 / 40 / 50", "dim"))
    out(line)
    out("  " + col(f"DazArgonMiner v{args.version}", "br"))
    out(line)
    out("  " + col("Address:", "r") + " " + args.address)
    out("  " + col("Work:", "r") + "    " + STATE["host"] + col("  (solo)", "dim"))
    if DEV_FEE_PCT > 0 and args.address != DEV_ADDRESS:
        fee = col(f"{DEV_FEE_PCT:g}%", "y") + col(f"  ({DEV_CYCLE * DEV_FEE_PCT / 100:.0f} s every {DEV_CYCLE // 60} min)", "dim")
    else:
        fee = col("0%", "g")
    out("  " + col("Dev Fee:", "r") + " " + fee)
    out("  " + col("Algorithm:", "r") + " " + col("Argon2id", "y") + col("  (t=1, m=8 MiB, p=1)", "dim"))
    if STATE["blocks"]:
        out("  " + col("Blocks:", "r") + "  " + col(f"{len(STATE['blocks'])} found so far", "bg"))
    out("  " + col("github.com/djdaz31/DazArgonMiner", "r"))
    out(line)
    arch = gpu_arch()
    for idx, bus, mem, name in gpus:
        out(col(f"GPU[{idx}]", "c") + f" {name} " + col("|", "dim") + " " + col(arch.get(idx, "sm_?"), "c")
            + " " + col("|", "dim") + f" {mem} MiB")
    out(col("Kernel List:", "bc"))
    out("  " + col("[0]", "bc") + col(" Original", "bold") + col("   one block of 128 threads per hash", "dim"))
    out("  " + col("[1]", "bc") + col(" Fast", "bold") + col("       one warp per hash, self-tested at start (default)", "dim"))
    if args.batch == "auto":
        out(col("Batch:", "bc") + col(" tuned per GPU" + (" (forced re-test)" if args.retune else ", saved in tune.json"), "dim"))
    else:
        out(col("Batch:", "bc") + f" {args.batch}" + col(" (fixed)", "dim"))


def display_loop(args, gpus):
    last_summary = time.time()
    while True:
        time.sleep(10)
        read_sensors()
        if time.time() - last_summary >= args.summary:
            summary(gpus, args)
            last_summary = time.time()
        else:
            status_line(gpus)


def stats_loop(args, gpus):
    while True:
        with LOCK:
            st = {
                "hs": [round(avg_rate(i, 30), 1) for i, *_ in gpus], "hs_units": "hs",
                "temp": [STATE["sens"].get(i, {}).get("temp", 0) for i, *_ in gpus],
                "fan": [STATE["sens"].get(i, {}).get("fan", 0) for i, *_ in gpus],
                "bus_numbers": [b for _, b, _, _ in gpus],
                "uptime": int(time.time() - STATE["start"]),
                "ar": [sum(STATE["acc"].values()), sum(STATE["rej"].values())],
                "algo": "argon2id", "ver": args.version,
            }
        try:
            tmp = args.stats + ".tmp"
            with open(tmp, "w") as f:
                json.dump(st, f)
            os.replace(tmp, args.stats)
        except Exception:                                           # noqa: BLE001
            pass
        time.sleep(10)


# ------------------------------------------------------------------ GPUs and work
def run_proc(args, gpu, batch, seconds, quiet=False, on_rate=None):
    """Run one argon_gpu process; returns the hashrates it printed. Hits are always submitted."""
    env = dict(os.environ, CUDA_VISIBLE_DEVICES=str(gpu))
    cmd = [args.bin, "--jobfile", args.jobfile, "--batch", str(batch),
           "--seconds", str(seconds), "--nonce-seed", str(gpu + 1)]
    proc = subprocess.Popen(cmd, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            text=True, bufsize=1, preexec_fn=die_with_parent)
    CHILDREN.append(proc)
    rates = []
    for line in proc.stdout:
        line = line.rstrip()
        m = RATE_RE.search(line)
        if m:
            r = float(m.group(1))
            rates.append(r)
            with LOCK:
                STATE["samples"].setdefault(gpu, collections.deque(maxlen=200)).append((time.time(), r))
            if on_rate:
                on_rate(r)
            continue
        if line.startswith("HIT "):
            parts = line.split()
            if len(parts) == 3 and parts[2].isdigit():
                threading.Thread(target=submit, args=(args, gpu, parts[1], int(parts[2])), daemon=True).start()
            else:
                log(f"GPU[{gpu}] malformed hit line ignored: {line}")
            continue
        if line.startswith("[job]") or line.startswith("argon_gpu:"):
            continue
        if "selftest" in line:
            ok = "OK" in line
            if not (quiet and ok):
                log(f"GPU[{gpu}] " + col(line, "g" if ok else "br"))
            continue
        log(f"GPU[{gpu}] {line}")
    proc.wait()
    try:
        CHILDREN.remove(proc)
    except ValueError:
        pass
    return proc, rates


def choose_batch(args, gpu, name, mem, bus):
    if args.batch != "auto":
        return int(args.batch)
    key = f"{short_name(name)}|{mem}MiB|bus{bus:02x}"
    cache = load_json(args.tune_file, {})
    if key in cache and not args.retune:
        b = int(cache[key]["batch"])
        log(f"GPU[{gpu}] batch {b} " + col(f"(tuned {cache[key].get('date', '?')}, --retune / retune=1 to redo)", "dim"))
        return b
    while STATE["height"] is None and not STOPPING.is_set():      # need a live job to mine while testing
        time.sleep(1)
    cands = tune_candidates(mem)
    with LOCK:
        TUNE["total"] += 1
        done, total = TUNE["done"], TUNE["total"]
    live_set("tunezzz", col(f"    {done}/{total} done", "dim"))
    if not (IS_TTY and USE_COLOR):
        log(f"GPU[{gpu}] tuning batch: {', '.join(map(str, cands))}  ({args.tune_seconds} s each, mining normally)")
    results = {}
    for n, b in enumerate(cands, 1):
        t0 = time.time()
        tick = [0]

        def draw(rate, b=b, n=n, t0=t0, tick=tick):
            tick[0] += 1
            frac = min(1.0, (time.time() - t0) / max(1, args.tune_seconds))
            w = 20
            fill = int(frac * w)
            bar = col("━" * fill, "c") + col("─" * (w - fill), "dim")
            live_set(f"tune{gpu:03d}", col(f"GPU {gpu:<2} ", "bc") + col(SPIN[tick[0] % len(SPIN)], "c")
                     + f"  batch {b:>4}  Test {n}/{len(cands)} [" + bar + "] "
                     + col(f"{int(frac * 100):>3}%", "g") + "  " + col(fmt_rate(rate), "bold"))
        draw(0.0)
        _, rates = run_proc(args, gpu, b, args.tune_seconds, quiet=True, on_rate=draw)
        if STOPPING.is_set():
            return b
        steady = rates[1:]                                         # first sample includes warm-up
        results[b] = sum(steady) / len(steady) if steady else 0.0
        if not (IS_TTY and USE_COLOR):
            log(f"GPU[{gpu}]   batch {b:>4}: " + (col(fmt_rate(results[b]), "g") if results[b] else col("failed (VRAM?)", "y")))
    with LOCK:
        TUNE["done"] += 1
        done, total = TUNE["done"], TUNE["total"]
    live_del(f"tune{gpu:03d}")
    if done < total:
        live_set("tunezzz", col(f"    {done}/{total} done", "dim"))
    else:
        live_del("tunezzz")
    if not any(results.values()):
        best = auto_batch(mem)
        log(col(f"GPU[{gpu}] tuning gave no result, using batch {best}", "y"))
        return best
    best = max(results, key=results.get)
    detail = "  ".join(f"{k}: {v / 1000:.1f}k" if v else f"{k}: -" for k, v in results.items())
    log(f"GPU[{gpu}] " + col(f"best batch {best}: {fmt_rate(results[best])}", "bg") + col(f"   ({detail})", "dim"))
    with LOCK:
        cache = load_json(args.tune_file, {})
        cache[key] = {"batch": best, "date": time.strftime("%Y-%m-%d %H:%M"),
                      "rates": {str(k): round(v) for k, v in results.items()}}
        save_json(args.tune_file, cache)
    return best


def run_gpu(args, gpu, name, mem, bus):
    batch = choose_batch(args, gpu, name, mem, bus)
    while not STOPPING.is_set():
        log(f"GPU[{gpu}] mining, batch {batch} " + col(f"({batch * 8 / 1024:.1f} GiB)", "dim"))
        proc, _ = run_proc(args, gpu, batch, 0)
        if STOPPING.is_set():
            return
        with LOCK:
            STATE["samples"].pop(gpu, None)
        log(col(f"GPU[{gpu}] miner exited rc={proc.returncode}, restart in 5 s", "br"))
        time.sleep(5)


def write_job(path, job):
    tmp = path + ".tmp"
    with open(tmp, "w") as f:
        f.write(job["job_id"] + "\n" + job["header_prefix"] + "\n" + job["target"] + "\n")
    os.replace(tmp, path)


def shutdown(*_):
    STOPPING.set()
    for p in CHILDREN:
        try:
            p.terminate()
        except Exception:                                           # noqa: BLE001
            pass
    sys.exit(0)


def main():
    global USE_COLOR
    ap = argparse.ArgumentParser()
    ap.add_argument("--address", required=True)
    ap.add_argument("--api", default="https://explorer.argonmine.com")
    ap.add_argument("--bin", default=os.path.join(HERE, "bin", "argon_gpu"))
    ap.add_argument("--jobfile", default="/run/argonmine_job.txt")
    ap.add_argument("--stats", default="/run/argonmine_stats.json")
    ap.add_argument("--blocks", default=os.path.join(HERE, "blocks.json"), help="where found blocks are kept")
    ap.add_argument("--tune-file", default=os.path.join(HERE, "tune.json"), help="saved best batch per GPU")
    ap.add_argument("--retune", action="store_true", help="test batch sizes again (after an OC change)")
    ap.add_argument("--tune-seconds", type=int, default=45)
    ap.add_argument("--refetch", type=float, default=60.0, help="seconds before a job is refreshed (jobs expire after 120)")
    ap.add_argument("--batch", default="auto", help="auto (tuned per GPU), or one number for every GPU")
    ap.add_argument("--devices", default="all", help="all, or a list like 0,1,3")
    ap.add_argument("--interval", type=float, default=2.0)
    ap.add_argument("--summary", type=int, default=60, help="seconds between GPU summary tables")
    ap.add_argument("--no-color", action="store_true")
    ap.add_argument("--log", help="also write every line to this file (HiveOS miner log)")
    ap.add_argument("--version", default="0.5.0")
    args = ap.parse_args()
    global LOGFILE
    if args.no_color:
        USE_COLOR = False
    if args.log:
        try:
            os.makedirs(os.path.dirname(os.path.abspath(args.log)), exist_ok=True)
            LOGFILE = open(args.log, "a", buffering=1)
        except Exception as e:                                      # noqa: BLE001
            print(f"cannot open log {args.log}: {e}", flush=True)

    if not re.fullmatch(r"arg1[0-9a-z]{20,100}", args.address):
        log(f"[config] '{args.address}' does not look like an ARG address (arg1...). Set it as the flight sheet wallet.")
        time.sleep(30)
        return 1
    args.api = args.api.rstrip("/")
    signal.signal(signal.SIGTERM, shutdown)
    signal.signal(signal.SIGINT, shutdown)
    signal.signal(signal.SIGHUP, shutdown)

    if not os.access(args.bin, os.X_OK):
        log(f"[config] miner binary missing: {args.bin} - run ./build.sh and send its output")
        time.sleep(60)
        return 1
    gpus = gpu_inventory()
    if args.devices != "all":
        want = {int(x) for x in args.devices.split(",") if x.strip()}
        gpus = [g for g in gpus if g[0] in want]
    if not gpus:
        log("[config] no GPU selected")
        return 1

    STATE["blocks"] = load_blocks(args.blocks)
    read_sensors()
    STATE["host"] = urllib.parse.urlparse(args.api).netloc or args.api
    print_banner(args, gpus)
    for idx, bus, mem, name in gpus:
        threading.Thread(target=run_gpu, args=(args, idx, name, mem, bus), daemon=True).start()
    threading.Thread(target=stats_loop, args=(args, gpus), daemon=True).start()
    threading.Thread(target=display_loop, args=(args, gpus), daemon=True).start()

    last_height, last_fetch, backoff, last_dev = None, 0.0, args.interval, False
    while True:
        now = time.time()
        dev = dev_active(args, now)
        if dev != last_dev:
            log(col("Dev fee window started (%d s)" % (DEV_CYCLE * DEV_FEE_PCT / 100) if dev else "Dev fee window ended", "dim"))
            last_dev, last_fetch = dev, 0.0                          # switch payout now
            with LOCK:
                STATE["dev"] = dev
        payout = DEV_ADDRESS if dev else args.address
        height = None
        try:
            height = http_json(args.api + "/api/health", timeout=10).get("indexedHeight")
        except Exception:                                           # noqa: BLE001
            pass
        if height != last_height or now - last_fetch > args.refetch:
            try:
                job = http_json(args.api + "/api/work?address=" + urllib.parse.quote(payout))
                if job.get("header_prefix"):
                    write_job(args.jobfile, job)
                    jh = job.get("height")
                    with LOCK:
                        STATE["jobs"][job["job_id"]] = (jh, payout)
                        while len(STATE["jobs"]) > 50:
                            STATE["jobs"].popitem(last=False)
                        new_height = jh != STATE["height"]
                        STATE["height"] = jh
                    if new_height:
                        log("New job " + col(f"height {jh}", "bm") + col(f"  target {job['target'][:12]}", "dim"))
                    last_height, last_fetch, backoff = height, now, args.interval
                else:
                    log(col(f"[work] {job}", "y"))
            except urllib.error.HTTPError as e:
                if e.code == 429:
                    backoff = min(backoff * 2, 60)
                    log(col(f"[work] rate-limited, waiting {backoff:.0f} s", "y"))
                    time.sleep(backoff)
                else:
                    log(col(f"[work] HTTP {e.code}", "y"))
            except Exception as e:                                  # noqa: BLE001
                log(col(f"[work] fetch failed: {e}", "y"))
        time.sleep(args.interval)


if __name__ == "__main__":
    sys.exit(main())
