#!/usr/bin/env bash
# Compiles bin/argon_gpu for RTX 30 (sm_86), 40 (sm_89) and 50 (sm_120).
# Source = src/argon_gpu.cu + patch_lowcpu.py + patch_fast.py; if the fast kernel does not compile,
# the original kernel is built instead. The binary also self-tests the fast kernel at every start.
# Compiler: system nvcc >= 12.8 if present, else NVIDIA's official redist archives downloaded into ./cuda.
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p bin build
ARCHS="-gencode arch=compute_86,code=sm_86 -gencode arch=compute_89,code=sm_89 -gencode arch=compute_120,code=sm_120 -gencode arch=compute_120,code=compute_120"

if ! command -v g++ >/dev/null; then
  echo "[build] installing g++"
  apt-get update -qq && apt-get install -y -qq g++
fi

if command -v nvcc >/dev/null && nvcc --version | grep -qE 'release 12\.(8|9)|release 1[3-9]'; then
  echo "[build] using system nvcc"
  NVCC=(nvcc -O3 $ARCHS)
else
  [[ -x cuda/bin/nvcc ]] || { rm -rf cuda; python3 fetch_cuda.py cuda; }
  export PATH="$PWD/cuda/bin:$PATH"
  NVCC=(nvcc -O3 $ARCHS -I cuda/include -L cuda/lib -L cuda/lib64)
fi

cp src/argon_gpu.cu build/base.cu
python3 patch_lowcpu.py build/base.cu
cp build/base.cu build/fast.cu
python3 patch_fast.py build/fast.cu

echo "[build] compiling fast kernel (1-3 min)"
if "${NVCC[@]}" -o bin/argon_gpu.tmp build/fast.cu; then
  echo "[build] fast kernel compiled"
else
  echo "[build] fast kernel did not compile - building the original kernel instead"
  "${NVCC[@]}" -o bin/argon_gpu.tmp build/base.cu
fi
mv bin/argon_gpu.tmp bin/argon_gpu
echo "[build] ok: $(ls -la bin/argon_gpu)"
