#!/usr/bin/env python3
"""Download NVIDIA's official CUDA redistributable archives (nvcc, cudart, cccl) and merge them into one folder.

Source: https://developer.download.nvidia.com/compute/cuda/redist/ (the same files the CUDA installer uses).
No pip, no apt. Standard library only. sha256 of every archive is checked against NVIDIA's manifest.
Usage: python3 fetch_cuda.py <dest_dir> [base_url]
"""
import hashlib
import json
import os
import shutil
import sys
import tarfile
import tempfile
import urllib.request

BASE = "https://developer.download.nvidia.com/compute/cuda/redist/"
RELEASES = ["12.9.1", "12.9.0", "12.8.1", "12.8.0"]     # >= 12.8 needed for RTX 50 (sm_120)
COMPONENTS = ["cuda_nvcc", "cuda_cudart", "cuda_cccl"]
PLATFORM = "linux-x86_64"


def get(url, timeout=120):
    with urllib.request.urlopen(url, timeout=timeout) as r:
        return r.read()


def main():
    dest = os.path.abspath(sys.argv[1])
    base = sys.argv[2] if len(sys.argv) > 2 else BASE
    manifest = None
    for rel in RELEASES:
        try:
            manifest = json.loads(get(base + f"redistrib_{rel}.json", 60))
            print(f"[fetch] CUDA {rel} redist manifest", flush=True)
            break
        except Exception as e:                                       # noqa: BLE001
            print(f"[fetch] redistrib_{rel}.json: {e}", flush=True)
    if not manifest:
        sys.exit("[fetch] cannot reach developer.download.nvidia.com")

    os.makedirs(dest, exist_ok=True)
    with tempfile.TemporaryDirectory() as tmp:
        for comp in COMPONENTS:
            info = manifest[comp][PLATFORM]
            url = base + info["relative_path"]
            print(f"[fetch] {comp} {manifest[comp]['version']} ({int(info.get('size', 0)) // 1048576} MB)", flush=True)
            data = get(url, 600)
            if hashlib.sha256(data).hexdigest() != info["sha256"]:
                sys.exit(f"[fetch] sha256 mismatch for {comp}")
            path = os.path.join(tmp, os.path.basename(url))
            with open(path, "wb") as f:
                f.write(data)
            del data
            out = os.path.join(tmp, comp)
            with tarfile.open(path) as t:
                try:
                    t.extractall(out, filter="tar")
                except TypeError:          # Python < 3.12
                    t.extractall(out)
            os.remove(path)
            top = os.path.join(out, os.listdir(out)[0])      # cuda_nvcc-linux-x86_64-<ver>-archive/
            shutil.copytree(top, dest, dirs_exist_ok=True, symlinks=True)
            shutil.rmtree(out)

    nvcc = os.path.join(dest, "bin", "nvcc")
    if not os.access(nvcc, os.X_OK):
        sys.exit(f"[fetch] nvcc missing after unpacking: {os.listdir(dest)}")
    print("[fetch] ok", flush=True)


if __name__ == "__main__":
    main()
