#!/usr/bin/env bash
# Flight sheet -> miner.conf
#   Wallet template : %WAL%            (your arg1... address)
#   Pool URL        : https://explorer.argonmine.com   (or your own node's explorer)
#   Extra config    : optional, e.g.  batch=768 devices=0,1 retune=1 tune=45
MINER_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
. "$MINER_DIR/h-manifest.conf"
ADDRESS=$(echo "$CUSTOM_TEMPLATE" | tr -d '[:space:]')
API=$(echo "$CUSTOM_URL" | tr -d '[:space:]')
[[ -z $API || $API == stratum* ]] && API=https://explorer.argonmine.com
BATCH=auto; DEVICES=all; RETUNE=; TUNE=45
# HiveOS only sets CUSTOM_* when it applies the flight sheet: never wipe a good config with empty values
if [[ -z $ADDRESS && -s $CUSTOM_CONFIG_FILENAME ]]; then return 0 2>/dev/null || exit 0; fi
for kv in $CUSTOM_USER_CONFIG; do
  case $kv in
    batch=*)   BATCH=${kv#batch=} ;;
    devices=*) DEVICES=${kv#devices=} ;;
    retune=1)  RETUNE=1 ;;
    tune=*)    TUNE=${kv#tune=} ;;
  esac
done
cat > "$CUSTOM_CONFIG_FILENAME" <<CONF
ADDRESS=$ADDRESS
API=$API
BATCH=$BATCH
DEVICES=$DEVICES
RETUNE=$RETUNE
TUNE=$TUNE
CONF
