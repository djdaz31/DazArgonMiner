#!/usr/bin/env bash
# Builds bin/argon_gpu ONCE and packages two ready-to-run archives (no compiling at deploy time):
#   dist/argonmine-cuda-<ver>.tar.gz        HiveOS custom miner
#   dist/argonmine-cuda-linux-<ver>.tar.gz  Ubuntu / WSL2  (./run.sh arg1...)
# Run it on the system with the OLDEST glibc you deploy to: a HiveOS rig is ideal, Ubuntu 24.04 / WSL2 run it too.
# Usage: ./make_release.sh            (fresh build)
#        ./make_release.sh --reuse    (package the existing bin/argon_gpu)
set -euo pipefail
cd "$(dirname "$0")"
. ./h-manifest.conf
VER=$CUSTOM_VERSION

if [[ ${1:-} != --reuse || ! -x bin/argon_gpu ]]; then
  rm -f bin/argon_gpu
  ./build.sh
fi

echo "[release] checking the binary"
grep -q usage <<<"$(./bin/argon_gpu 2>&1 || true)" || { echo "[release] bin/argon_gpu does not run"; exit 1; }
if command -v nvidia-smi >/dev/null && nvidia-smi -L >/dev/null 2>&1; then
  CUDA_VISIBLE_DEVICES=${SELFTEST_GPU:-0} ./bin/argon_gpu --selftest || { echo "[release] selftest failed - not packaging"; exit 1; }
else
  echo "[release] no NVIDIA GPU visible: selftest skipped"
fi
GLIBC=$(objdump -T bin/argon_gpu 2>/dev/null | grep -o 'GLIBC_[0-9.]*' | sort -V | tail -1 || true)
ARCHS=$(cuobjdump --list-elf bin/argon_gpu 2>/dev/null | grep -o 'sm_[0-9]*' | sort -u | tr '\n' ' ' || true)
[[ -z $ARCHS ]] && ARCHS=$(PATH="$PWD/cuda/bin:$PATH" cuobjdump --list-elf bin/argon_gpu 2>/dev/null | grep -o 'sm_[0-9]*' | sort -u | tr '\n' ' ' || true)

COMMON=(argonmine_hive.py build.sh fetch_cuda.py patch_lowcpu.py patch_fast.py src tools LICENSE LICENSE.argon_gpu)
rm -rf dist && mkdir -p dist/hiveos/argonmine-cuda/bin dist/linux/argonmine-cuda/bin
cp -r "${COMMON[@]}" h-manifest.conf h-config.sh h-run.sh h-stats.sh LISEZMOI.txt dist/hiveos/argonmine-cuda/
cp -r "${COMMON[@]}" run.sh dist/linux/argonmine-cuda/
cp bin/argon_gpu dist/hiveos/argonmine-cuda/bin/
cp bin/argon_gpu dist/linux/argonmine-cuda/bin/
for f in dist/*/argonmine-cuda; do
  printf 'argon_gpu %s\nbuilt   %s on %s\nglibc   %s or newer\narchs   %s\n' "$VER" "$(date '+%Y-%m-%d %H:%M')" \
    "$(. /etc/os-release 2>/dev/null; echo "${PRETTY_NAME:-unknown}")" "${GLIBC#GLIBC_}" "${ARCHS:-unknown}" > "$f/BUILD_INFO.txt"
done
find dist -name __pycache__ -prune -exec rm -rf {} +
tar --owner=0 --group=0 -C dist/hiveos -czf "dist/argonmine-cuda-$VER.tar.gz" argonmine-cuda
tar --owner=0 --group=0 -C dist/linux  -czf "dist/argonmine-cuda-linux-$VER.tar.gz" argonmine-cuda
rm -rf dist/hiveos dist/linux

echo
echo "[release] ready:"
( cd dist && sha256sum *.tar.gz )
echo "[release] binary needs ${GLIBC:-?} or newer; GPU code for: ${ARCHS:-?}"
