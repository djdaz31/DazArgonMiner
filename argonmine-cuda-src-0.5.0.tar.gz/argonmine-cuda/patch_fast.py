#!/usr/bin/env python3
"""Fast-kernel patch for argon_gpu.cu (idempotent). Apply after patch_lowcpu.py.

New fill kernel: one warp (32 threads) per hash instead of 128 threads,
previous block kept in registers (no re-read from VRAM), no __syncthreads,
no divergent __constant__ lookups. 4 hashes per CUDA block.
Startup self-test against a known-answer tag; falls back to the original kernel on mismatch.
Set ARGON_KERNEL=orig to force the original kernel.
Usage: python3 patch_fast.py path/to/argon_gpu.cu
"""
import sys

p = sys.argv[1]
s = open(p).read()
if "fill_kernel_w" in s:
    print("[patch] fast kernel already applied")
    sys.exit(0)

KERNEL = r'''
// ------------------------------------------------- fast fill kernel (warp per hash)
__device__ __forceinline__ uint64_t fBlaMkaW(uint64_t x, uint64_t y) {
    return x + y + 2ULL * ((uint64_t)(uint32_t)x * (uint64_t)(uint32_t)y);
}
__device__ __forceinline__ void gW(uint64_t &a, uint64_t &b, uint64_t &c, uint64_t &d) {
    a = fBlaMkaW(a, b); d = rotr64(d ^ a, 32);
    c = fBlaMkaW(c, d); b = rotr64(b ^ c, 24);
    a = fBlaMkaW(a, b); d = rotr64(d ^ a, 16);
    c = fBlaMkaW(c, d); b = rotr64(b ^ c, 63);
}
__device__ __forceinline__ void gS(uint64_t *S, int i0, int i1, int i2, int i3) {
    uint64_t a = S[i0], b = S[i1], c = S[i2], d = S[i3];
    gW(a, b, c, d);
    S[i0] = a; S[i1] = b; S[i2] = c; S[i3] = d;
}
// X[k] = qword (lane + 32k) of the block; returns P(block) in the same layout
__device__ __forceinline__ void perm_w(uint64_t *S, uint64_t X[4], int lane) {
    const int g = lane >> 2, j = lane & 3;
    const int j1 = (j + 1) & 3, j2 = (j + 2) & 3, j3 = (j + 3) & 3;
    __syncwarp();
#pragma unroll
    for (int k = 0; k < 4; k++) S[lane + 32 * k] = X[k];
    __syncwarp();
    const int r = 16 * g;
    gS(S, r + j, r + 4 + j, r + 8 + j, r + 12 + j);    __syncwarp();
    gS(S, r + j, r + 4 + j1, r + 8 + j2, r + 12 + j3); __syncwarp();
#define CP(p) (2 * g + 16 * ((p) >> 1) + ((p) & 1))
    gS(S, CP(j), CP(4 + j), CP(8 + j), CP(12 + j));     __syncwarp();
    gS(S, CP(j), CP(4 + j1), CP(8 + j2), CP(12 + j3));  __syncwarp();
#undef CP
#pragma unroll
    for (int k = 0; k < 4; k++) X[k] = S[lane + 32 * k];
}

__global__ void __launch_bounds__(128) fill_kernel_w(uint64_t *mem, int hashes) {
    const int lane = threadIdx.x & 31, w = threadIdx.x >> 5;
    const int hid = blockIdx.x * 4 + w;
    __shared__ uint64_t SH[4][128], ADS[4][128];
    if (hid >= hashes) return;                  // whole warp leaves; no block-wide barriers below
    uint64_t *S = SH[w], *AD = ADS[w];
    uint64_t *B = mem + (size_t)hid * 1048576ULL;
    uint64_t prev[4], X[4], R[4];
#pragma unroll
    for (int k = 0; k < 4; k++) prev[k] = B[128 + lane + 32 * k];    // block 1

    for (int slice = 0; slice < 4; slice++) {
        const int indie = (slice < 2);
        const int start = (slice == 0) ? 2 : 0;
        uint64_t ctr = 0;
        for (int i = start; i < 2048; i++) {
            if (indie && (i == start || (i & 127) == 0)) {
                ctr++;
#pragma unroll
                for (int k = 0; k < 4; k++) {
                    const int q = lane + 32 * k;
                    X[k] = (q == 2) ? (uint64_t)slice : (q == 3) ? 8192ULL : (q == 4) ? 1ULL
                         : (q == 5) ? 2ULL : (q == 6) ? ctr : 0ULL;
                    R[k] = X[k];
                }
                perm_w(S, X, lane);
#pragma unroll
                for (int k = 0; k < 4; k++) { X[k] ^= R[k]; R[k] = X[k]; }
                perm_w(S, X, lane);
#pragma unroll
                for (int k = 0; k < 4; k++) AD[lane + 32 * k] = X[k] ^ R[k];
                __syncwarp();
            }
            const uint32_t abs_idx = (uint32_t)slice * 2048u + (uint32_t)i;
            const uint64_t p0 = __shfl_sync(0xffffffffu, prev[0], 0);
            const uint32_t pr = indie ? (uint32_t)AD[i & 127] : (uint32_t)p0;
            const uint32_t ref = index_alpha((uint32_t)slice, (uint32_t)i, pr);
            const uint64_t *rb = B + (size_t)ref * 128;
#pragma unroll
            for (int k = 0; k < 4; k++) { R[k] = prev[k] ^ rb[lane + 32 * k]; X[k] = R[k]; }
            perm_w(S, X, lane);
            uint64_t *cb = B + (size_t)abs_idx * 128;
#pragma unroll
            for (int k = 0; k < 4; k++) { X[k] ^= R[k]; cb[lane + 32 * k] = X[k]; prev[k] = X[k]; }
            __syncwarp();                           // later reads of this block by other lanes
        }
    }
}
'''

SELFTEST = r'''
// ------------------------------------------------------------ known-answer self-test
// argon2id(password = bytes 00..77, salt "Argonmine/pow/v1", t=1, m=8192 KiB, p=1, 32 bytes)
static const char *KAT_TAG = "1086b547f21e33f9367b8baae4bd578c770397316b5f09a4c4cc22a049a41f68";
static int run_selftest(int fast, uint8_t *d_hdr, uint8_t *d_mem, unsigned long long *d_hit, uint8_t *d_tag0) {
    uint8_t hdr[120];
    for (int i = 0; i < 120; i++) hdr[i] = (uint8_t)i;
    CUDA_CHECK(cudaMemcpy(d_hdr, hdr, 120, cudaMemcpyHostToDevice));
    prepare_kernel<<<1, 1>>>(d_hdr, d_mem, 1, NULL);
    if (fast) fill_kernel_w<<<1, 128>>>((uint64_t *)d_mem, 1);
    else      fill_kernel<<<1, 128>>>((uint64_t *)d_mem, 1, 0);
    finalize_kernel<<<1, 1>>>(d_mem, NULL, 0, 1, d_hit, d_tag0);
    CUDA_CHECK(cudaGetLastError());
    uint8_t tag[32]; char hex[65];
    CUDA_CHECK(cudaMemcpy(tag, d_tag0, 32, cudaMemcpyDeviceToHost));
    for (int i = 0; i < 32; i++) sprintf(hex + 2 * i, "%02x", tag[i]);
    int ok = !strcmp(hex, KAT_TAG);
    printf("[selftest] %s kernel: %s\n", fast ? "fast" : "original", ok ? "OK" : "MISMATCH");
    fflush(stdout);
    return ok;
}
'''

anchor_k = "// ------------------------------------------------------------- finalize kernel"
anchor_h = "// ----------------------------------------------------------------------- host"
need = [
    anchor_k, anchor_h,
    '        else if (!strcmp(argv[i], "--dump")) dump = 1;',
    '        // ---- long-running mode: job comes from a file, refreshed by the driver',
    '        fill_kernel<<<batch, 128>>>((uint64_t *)d_mem, batch, 0);',
    'int batch = 1024, seconds = 15, dump = 0, seconds_given = 0;',
    '    for (int i = 1; i < argc; i++) if (!strcmp(argv[i], "--jobfile")) want_jobfile = 1;',
]
for n in need:
    if s.count(n) != 1:
        sys.exit(f"[patch] source not recognised ({n[:50]}...), nothing changed")

s = s.replace(anchor_k, KERNEL + "\n" + anchor_k, 1)
s = s.replace(anchor_h, SELFTEST + "\n" + anchor_h, 1)
s = s.replace('int batch = 1024, seconds = 15, dump = 0, seconds_given = 0;',
              'int batch = 1024, seconds = 15, dump = 0, seconds_given = 0, selftest_only = 0;', 1)
s = s.replace('        else if (!strcmp(argv[i], "--dump")) dump = 1;',
              '        else if (!strcmp(argv[i], "--dump")) dump = 1;\n'
              '        else if (!strcmp(argv[i], "--selftest")) selftest_only = 1;', 1)
s = s.replace('    for (int i = 1; i < argc; i++) if (!strcmp(argv[i], "--jobfile")) want_jobfile = 1;',
              '    for (int i = 1; i < argc; i++) if (!strcmp(argv[i], "--jobfile")) want_jobfile = 1;\n'
              '    if (selftest_only) { want_jobfile = 1; batch = 1; }   // daemon defaults, 8 MiB of VRAM', 1)
s = s.replace('        // ---- long-running mode: job comes from a file, refreshed by the driver',
              '    int use_fast = !(getenv("ARGON_KERNEL") && !strcmp(getenv("ARGON_KERNEL"), "orig"));\n'
              '    if (selftest_only) {\n'
              '        int a = run_selftest(1, d_hdr, d_mem, d_hit, d_tag0), b = run_selftest(0, d_hdr, d_mem, d_hit, d_tag0);\n'
              '        return (a && b) ? 0 : 3;\n'
              '    }\n'
              '    if (use_fast && !run_selftest(1, d_hdr, d_mem, d_hit, d_tag0)) {\n'
              '        printf("[selftest] fast kernel gives wrong hashes on this GPU - falling back to the original kernel\\n");\n'
              '        use_fast = 0;\n'
              '    }\n'
              '    if (!use_fast && !run_selftest(0, d_hdr, d_mem, d_hit, d_tag0)) {\n'
              '        printf("[selftest] original kernel also wrong - refusing to mine (check overclock)\\n");\n'
              '        return 4;\n'
              '    }\n'
              '        // ---- long-running mode: job comes from a file, refreshed by the driver', 1)
s = s.replace('        fill_kernel<<<batch, 128>>>((uint64_t *)d_mem, batch, 0);',
              '        if (use_fast) fill_kernel_w<<<(batch + 3) / 4, 128>>>((uint64_t *)d_mem, batch);\n'
              '        else          fill_kernel<<<batch, 128>>>((uint64_t *)d_mem, batch, 0);', 1)
open(p, "w").write(s)
print("[patch] fast kernel applied")
