#!/usr/bin/env python3
"""Low-CPU patch for src/argon_gpu.cu (idempotent).

1. cudaDeviceScheduleBlockingSync: the CPU thread sleeps while the GPU works instead of spinning
   (without it, each GPU process keeps one CPU core at 100 %).
2. Print the hashrate every ~2 s instead of after every batch.
Usage: python3 patch_lowcpu.py [path/to/argon_gpu.cu]
"""
import sys

p = sys.argv[1] if len(sys.argv) > 1 else "src/argon_gpu.cu"
s = open(p).read()
if "cudaDeviceScheduleBlockingSync" in s:
    print("[patch] already applied")
    sys.exit(0)

a = "    size_t memsz = (size_t)batch * 8388608ULL;"
b = '        printf("  %d hashes in %7.1f ms -> %8.1f H/s   (total %lld)\\n", batch, ms, batch * 1000.0 / ms, done);'
if s.count(a) != 1 or s.count(b) != 1:
    sys.exit("[patch] source not recognised, nothing changed")

s = s.replace(a, "    // low-CPU patch: sleep on the GPU instead of spinning a CPU core\n"
                 "    CUDA_CHECK(cudaSetDeviceFlags(cudaDeviceScheduleBlockingSync));\n" + a, 1)
s = s.replace(b,
              "        static double last_print = 0, acc_ms = 0; static long long acc_h = 0;\n"
              "        acc_ms += ms; acc_h += batch;\n"
              "        if (now_ms() - last_print >= 2000.0) {\n"
              "            printf(\"  %lld hashes in %7.1f ms -> %8.1f H/s   (total %lld)\\n\", acc_h, acc_ms, acc_h * 1000.0 / acc_ms, done);\n"
              "            last_print = now_ms(); acc_ms = 0; acc_h = 0;\n"
              "        }", 1)
open(p, "w").write(s)
print("[patch] applied")
