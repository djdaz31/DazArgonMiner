#!/usr/bin/env bash
# Ubuntu / WSL2 launcher.   ./run.sh arg1YOURADDRESS [options]
# options: --devices 0,1   --batch 768   --retune   --tune-seconds 30   --interval 4   --no-color
cd "$(dirname "$0")"
if [[ $# -lt 1 || $1 != arg1* ]]; then
  echo "usage: ./run.sh arg1YOURADDRESS [--devices 0,1] [--retune] [--interval 4] ..."; exit 1
fi
ADDR=$1; shift
if [[ -x bin/argon_gpu ]] && ! grep -q usage <<<"$(bin/argon_gpu 2>&1 || true)"; then
  echo "[run] bundled binary does not run on this system: $(bin/argon_gpu 2>&1 | head -1)"
  echo "[run] rebuilding from source (needs g++ and python3)"
  mv -f bin/argon_gpu bin/argon_gpu.bundled
fi
if [[ ! -x bin/argon_gpu ]]; then ./build.sh || exit 1; fi
D=${XDG_RUNTIME_DIR:-/tmp}
[[ -w $D ]] || D=/tmp
exec python3 -u argonmine_hive.py --address "$ADDR" --jobfile "$D/argonmine_job.txt" --stats "$D/argonmine_stats.json" "$@"
