"""Reference Argon2id (RFC 9106, v0x13) in pure Python + a lane-by-lane simulation of the warp kernel.

python3 argon2ref.py rfc        -> checks the RFC 9106 argon2id test vector
python3 argon2ref.py kat        -> Argonmine known-answer tag for a fixed header (reference)
python3 argon2ref.py warpsim    -> same header through a simulation of the new CUDA warp kernel
"""
import hashlib
import struct
import sys

M64 = (1 << 64) - 1


def b2(data, n):
    return hashlib.blake2b(data, digest_size=n).digest()


def Hprime(n, x):
    x = struct.pack("<I", n) + x
    if n <= 64:
        return b2(x, n)
    r = (n + 31) // 32 - 2
    v = b2(x, 64)
    out = v[:32]
    for _ in range(2, r + 1):
        v = b2(v, 64)
        out += v[:32]
    return out + b2(v, n - 32 * r)


def rotr(x, n):
    return ((x >> n) | (x << (64 - n))) & M64


def G(v, a, b, c, d):
    va, vb, vc, vd = v[a], v[b], v[c], v[d]
    va = (va + vb + 2 * (va & 0xFFFFFFFF) * (vb & 0xFFFFFFFF)) & M64
    vd = rotr(vd ^ va, 32)
    vc = (vc + vd + 2 * (vc & 0xFFFFFFFF) * (vd & 0xFFFFFFFF)) & M64
    vb = rotr(vb ^ vc, 24)
    va = (va + vb + 2 * (va & 0xFFFFFFFF) * (vb & 0xFFFFFFFF)) & M64
    vd = rotr(vd ^ va, 16)
    vc = (vc + vd + 2 * (vc & 0xFFFFFFFF) * (vd & 0xFFFFFFFF)) & M64
    vb = rotr(vb ^ vc, 63)
    v[a], v[b], v[c], v[d] = va, vb, vc, vd


def P16(v, idx):
    i = idx
    G(v, i[0], i[4], i[8], i[12]); G(v, i[1], i[5], i[9], i[13])
    G(v, i[2], i[6], i[10], i[14]); G(v, i[3], i[7], i[11], i[15])
    G(v, i[0], i[5], i[10], i[15]); G(v, i[1], i[6], i[11], i[12])
    G(v, i[2], i[7], i[8], i[13]); G(v, i[3], i[4], i[9], i[14])


def perm(R):
    """RFC 9106 permutation applied to a 128-qword block (rows, then columns)."""
    v = list(R)
    for r in range(8):
        P16(v, [16 * r + k for k in range(16)])
    for c in range(8):
        P16(v, [2 * c + 16 * (p >> 1) + (p & 1) for p in range(16)])
    return v


def comp(X, Y):
    R = [x ^ y for x, y in zip(X, Y)]
    Q = perm(R)
    return [q ^ r for q, r in zip(Q, R)]


def to_q(b):
    return list(struct.unpack("<128Q", b))


def from_q(q):
    return struct.pack("<128Q", *q)


def argon2id(pwd, salt, t, m_kib, p, taglen, secret=b"", ad=b""):
    """Generic argon2id, any t/p (used for the RFC vector)."""
    h0 = b2(struct.pack("<IIIIII", p, taglen, m_kib, t, 0x13, 2)
            + struct.pack("<I", len(pwd)) + pwd + struct.pack("<I", len(salt)) + salt
            + struct.pack("<I", len(secret)) + secret + struct.pack("<I", len(ad)) + ad, 64)
    m = 4 * p * (m_kib // (4 * p))
    q = m // p
    seg = q // 4
    B = [[None] * q for _ in range(p)]
    for l in range(p):
        B[l][0] = to_q(Hprime(1024, h0 + struct.pack("<II", 0, l)))
        B[l][1] = to_q(Hprime(1024, h0 + struct.pack("<II", 1, l)))
    for ps in range(t):
        for s in range(4):
            for l in range(p):
                indep = ps == 0 and s < 2
                addr, ctr = None, 0
                for idx in range(seg):
                    if ps == 0 and s == 0 and idx < 2:
                        continue
                    j = s * seg + idx
                    prev = B[l][j - 1] if j else B[l][q - 1]
                    if indep:
                        if addr is None or idx % 128 == 0:
                            ctr += 1
                            inp = [ps, l, s, m, t, 2, ctr] + [0] * 121
                            z = [0] * 128
                            addr = comp(z, comp(z, inp))
                        J = addr[idx % 128]
                    else:
                        J = prev[0]
                    J1, J2 = J & 0xFFFFFFFF, J >> 32
                    rl = l if (ps == 0 and s == 0) else J2 % p
                    if ps == 0:
                        if rl == l:
                            area = s * seg + idx - 1
                        else:
                            area = s * seg - (1 if idx == 0 else 0)
                        start = 0
                    else:
                        area = q - seg + idx - 1 if rl == l else q - seg - (1 if idx == 0 else 0)
                        start = ((s + 1) * seg) % q
                    x = (J1 * J1) >> 32
                    y = (area * x) >> 32
                    z = area - 1 - y
                    ref = (start + z) % q
                    new = comp(prev, B[rl][ref])
                    if ps > 0:
                        new = [a ^ b for a, b in zip(new, B[l][j])]
                    B[l][j] = new
    C = B[0][q - 1]
    for l in range(1, p):
        C = [a ^ b for a, b in zip(C, B[l][q - 1])]
    return Hprime(taglen, from_q(C))


SALT = b"Argonmine/pow/v1"
KAT_HEADER = bytes(range(120))           # fixed test header 00 01 .. 77


def argonmine(header):
    return argon2id(header, SALT, 1, 8192, 1, 32)


# ---------------------------------------------------------------- warp kernel simulation
def lane_perm(R):
    """Simulates perm_P of the CUDA warp kernel: 32 lanes, lane L owns qwords L+32k,
    G work split exactly like the kernel (row phase then column phase, 4 G per row/col)."""
    S = list(R)                                   # shared S[128] after the store
    def run(phase_idx):
        for step in range(2):                     # column step, then diagonal step
            work = []
            for lane in range(32):
                g, j = lane >> 2, lane & 3
                if step == 0:
                    pos = [j, 4 + j, 8 + j, 12 + j]
                else:
                    pos = [j, 4 + ((j + 1) & 3), 8 + ((j + 2) & 3), 12 + ((j + 3) & 3)]
                work.append([phase_idx(g, p) for p in pos])
            # every lane loads before anyone stores (separate G groups never overlap)
            flat = [i for w in work for i in w]
            assert len(set(flat)) == 128, "lanes overlap"
            for a, b, c, d in work:
                G(S, a, b, c, d)
    run(lambda g, p: 16 * g + p)                                  # rows
    run(lambda g, p: 2 * g + 16 * (p >> 1) + (p & 1))             # columns
    return S


def warp_kernel_sim(header):
    h0 = b2(struct.pack("<IIIIII", 1, 32, 8192, 1, 0x13, 2) + struct.pack("<I", 120) + header
            + struct.pack("<I", 16) + SALT + struct.pack("<II", 0, 0), 64)
    B = [None] * 8192
    B[0] = to_q(Hprime(1024, h0 + struct.pack("<II", 0, 0)))
    B[1] = to_q(Hprime(1024, h0 + struct.pack("<II", 1, 0)))
    prev = B[1]                                   # kernel keeps prev in registers
    for s in range(4):
        indie = s < 2
        start = 2 if s == 0 else 0
        ctr = 0
        AD = None
        for i in range(start, 2048):
            if indie and (i == start or (i & 127) == 0):
                ctr += 1
                X = [0, 0, s, 8192, 1, 2, ctr] + [0] * 121
                Q = lane_perm(X); X = [a ^ b for a, b in zip(Q, X)]
                Q = lane_perm(X); AD = [a ^ b for a, b in zip(Q, X)]
            ab = s * 2048 + i
            pr = (AD[i & 127] if indie else prev[0]) & 0xFFFFFFFF
            area = (i - 1) if s == 0 else (s * 2048 + i - 1)
            rel = (pr * pr) >> 32
            rel = area - 1 - ((area * rel) >> 32)
            ref = rel % 8192
            R = [a ^ b for a, b in zip(prev, B[ref])]
            Q = lane_perm(R)
            new = [a ^ b for a, b in zip(Q, R)]
            B[ab] = new
            prev = new
    return Hprime(32, from_q(B[8191]))


if __name__ == "__main__":
    what = sys.argv[1]
    if what == "rfc":
        tag = argon2id(b"\x01" * 32, b"\x02" * 16, 3, 32, 4, 32, b"\x03" * 8, b"\x04" * 12)
        exp = "0d640df58d78766c08c037a34a8b53c9d01ef0452d75b65eb52520e96b01e659"
        print(tag.hex(), "OK" if tag.hex() == exp else "MISMATCH")
    elif what == "kat":
        print(argonmine(KAT_HEADER).hex())
    elif what == "warpsim":
        print(warp_kernel_sim(KAT_HEADER).hex())
