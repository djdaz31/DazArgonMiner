#!/usr/bin/env python3
"""DazArgonMiner driver (HiveOS, Ubuntu, WSL2) - Argonmine (ARG), Argon2id, solo.

One work fetcher for the whole rig, one argon_gpu process per GPU (own nonce range), hits are
submitted with the rig's address. On first start every GPU tests the kernels (fast2 / fast) and
then the batch sizes, keeps the fastest pair and saves it in tune.json.

On a terminal (HiveOS `miner` screen, tmux, WSL) the console is a dashboard refreshed in place.
Without a terminal (pipes, --no-dashboard, NO_COLOR) it prints plain tagged lines.
--log FILE always receives plain lines: events plus a summary every minute (HiveOS `miner log`).

Based on driver/gpumine.py from github.com/YGYxop6/argonmine-cuda-miner (MIT).
"""
import argparse
import collections
import ctypes
import json
import math
import os
import re
import shutil
import signal
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
VERSION = "0.6.0"
RATE_RE = re.compile(r"->\s*([0-9.]+)\s*H/s")
BLOCK_NET = 49.5            # 50 ARG subsidy minus the 1 % treasury share
MATURITY = 100

# ---- dev fee (time based) ------------------------------------------------------------
# DEV_FEE_PCT % of mining time sends its work to DEV_ADDRESS: 1 % = 60 s every 100 min.
# Shown at start-up and on the dashboard while active. Set DEV_FEE_PCT = 0 to turn it off.
DEV_ADDRESS = "arg1q56234qn7f2mym8sjj7m4uww2aghgh8pah4q6gnnpusrutfqkn45shvc7tz"
DEV_FEE_PCT = 1.0
DEV_CYCLE = 6000            # seconds
DEV_OFFSET = 1800           # first dev window 30 min after start (after tuning)

KERNELS = ("fast2", "fast")                 # tested per GPU; "orig" stays the self-test fallback
LOCK = threading.Lock()
STATE = {
    "start": time.time(),
    "samples": {},        # gpu -> deque[(t, H/s)]
    "acc": {}, "rej": {}, # gpu -> count (this session)
    "sens": {},           # gpu -> dict(power, temp, core, mem, fan)
    "kernel": {},         # gpu -> kernel actually running
    "batch": {},          # gpu -> batch
    "gstate": {},         # gpu -> tuning | mining | restarting
    "height": None,       # current job height
    "target": None,       # current job target (int)
    "heights": collections.deque(maxlen=40),   # (time, height) when the tip moved
    "jobs": collections.OrderedDict(),         # job_id -> (height, payout address)
    "dev": False, "dev_until": 0.0,
    "blocks": [],         # all accepted blocks, persisted
    "round_start": time.time(),
    "flash_until": 0.0,
    "warned": {},         # gpu -> last temperature warning time
}
EVENTS = collections.deque(maxlen=50)
CHILDREN = []
STOPPING = threading.Event()
TUNE = {"total": 0, "done": 0}

# ------------------------------------------------------------------ colours / output
USE_COLOR = not os.environ.get("NO_COLOR")
C = {"r": "31", "g": "32", "y": "33", "b": "34", "m": "35", "c": "36", "w": "37", "dim": "2", "bold": "1",
     "bg": "1;32", "by": "1;33", "bc": "1;36", "bm": "1;35", "br": "1;31", "bb": "1;34", "violet": "38;5;135"}


def col(text, c):
    if not USE_COLOR:
        return str(text)
    return f"\033[{C[c]}m{text}\033[0m"


VIS_RE = re.compile(r"\033\[[0-9;?]*[A-Za-z]")


def vlen(s):
    return len(VIS_RE.sub("", s))


def trunc(s, w):
    """Cut a coloured string to w visible characters."""
    if vlen(s) <= w:
        return s
    out_, n, i = [], 0, 0
    while i < len(s) and n < w - 1:
        m = VIS_RE.match(s, i)
        if m:
            out_.append(m.group(0))
            i = m.end()
            continue
        out_.append(s[i])
        n += 1
        i += 1
    return "".join(out_) + "…" + ("\033[0m" if USE_COLOR else "")


def pad(s, w, right=True):
    n = w - vlen(s)
    return (" " * n + s) if right else (s + " " * n)


OUT_LOCK = threading.Lock()
LOGFILE = None                           # --log: plain lines (events + minute summaries)
IS_TTY = sys.stdout.isatty()
DASH = {"on": False, "active": False}    # on: dashboard mode chosen; active: dashboard is drawing
LIVE = collections.OrderedDict()         # progress lines redrawn at the bottom (launch phase)
LIVE_SHOWN = [0]


def _live_clear():
    if LIVE_SHOWN[0]:
        sys.stdout.write("\033[%dF\033[J" % LIVE_SHOWN[0])
        LIVE_SHOWN[0] = 0


def _live_draw():
    for key in sorted(LIVE):
        sys.stdout.write(LIVE[key] + "\n")
    LIVE_SHOWN[0] = len(LIVE)


def to_log(msg):
    if LOGFILE:
        try:
            LOGFILE.write(VIS_RE.sub("", msg) + "\n")
            LOGFILE.flush()
        except Exception:                                           # noqa: BLE001
            pass


def out(msg=""):
    """Print a line (launch phase / plain mode). Ignored on screen while the dashboard draws."""
    with OUT_LOCK:
        to_log(msg)
        if DASH["active"]:
            return
        _live_clear()
        sys.stdout.write(msg + "\n")
        _live_draw()
        sys.stdout.flush()


def log(msg, level="info"):
    """Timestamped event: printed in plain mode, shown in the dashboard's event list."""
    ts = time.strftime("%H:%M:%S")
    with LOCK:
        EVENTS.append((time.strftime("%H:%M"), msg, level))
    out(col(ts + " ", "dim") + msg)


def live_set(key, text):
    if not (IS_TTY and USE_COLOR) or DASH["active"]:
        return
    with OUT_LOCK:
        _live_clear()
        LIVE[key] = text
        _live_draw()
        sys.stdout.flush()


def live_del(*keys):
    if not (IS_TTY and USE_COLOR):
        return
    with OUT_LOCK:
        _live_clear()
        for k in keys:
            LIVE.pop(k, None)
        if not DASH["active"]:
            _live_draw()
        sys.stdout.flush()


SPIN = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"


def fmt_rate(hs):
    for unit, div in (("TH/s", 1e12), ("GH/s", 1e9), ("MH/s", 1e6), ("kH/s", 1e3)):
        if hs >= div:
            return f"{hs / div:.2f} {unit}" if hs < div * 100 else f"{hs / div:.1f} {unit}"
    return f"{hs:.0f} H/s"


def fmt_dur(sec):
    sec = int(max(0, sec))
    d, sec = divmod(sec, 86400)
    h, sec = divmod(sec, 3600)
    m, _ = divmod(sec, 60)
    return (f"{d}d " if d else "") + f"{h:02d}h{m:02d}"


def fmt_eta(sec):
    if sec is None or not math.isfinite(sec):
        return "—"
    sec = int(sec)
    if sec < 3600:
        return f"{sec // 60} min"
    if sec < 86400:
        return f"{sec // 3600} h {sec % 3600 // 60:02d} min"
    d = sec / 86400
    return f"{d:.1f} days" if d < 100 else f"{d:.0f} days"


def thousands(n):
    return f"{n:,}".replace(",", " ")


# ------------------------------------------------------------------ helpers
def http_json(url, data=None, timeout=20):
    req = urllib.request.Request(url, method="POST" if data is not None else "GET")
    body = None
    if data is not None:
        body = json.dumps(data).encode()
        req.add_header("Content-Type", "application/json")
    with urllib.request.urlopen(req, body, timeout=timeout) as r:
        return json.loads(r.read().decode())


def gpu_inventory():
    """[(index, bus_number, total_MiB, name)] from nvidia-smi."""
    res = subprocess.run(
        ["nvidia-smi", "--query-gpu=index,pci.bus_id,memory.total,name", "--format=csv,noheader,nounits"],
        capture_output=True, text=True, check=True).stdout
    gpus = []
    for line in res.strip().splitlines():
        idx, bus, mem, name = [x.strip() for x in line.split(",", 3)]
        bus_num = int(bus.split(":")[-2], 16)          # 00000000:0A:00.0 -> 10
        gpus.append((int(idx), bus_num, int(float(mem)), name))
    return gpus


def gpu_arch():
    try:
        res = subprocess.run(["nvidia-smi", "--query-gpu=index,compute_cap", "--format=csv,noheader"],
                             capture_output=True, text=True, timeout=10).stdout
        arch = {}
        for line in res.strip().splitlines():
            i, cc = [x.strip() for x in line.split(",")]
            if i.isdigit() and re.fullmatch(r"\d+\.\d+", cc):
                arch[int(i)] = "sm_" + cc.replace(".", "")
        return arch
    except Exception:                                               # noqa: BLE001
        return {}


def num(x):
    try:
        return float(x)
    except ValueError:
        return 0.0


def read_sensors():
    try:
        res = subprocess.run(
            ["nvidia-smi", "--query-gpu=index,power.draw,temperature.gpu,clocks.sm,clocks.mem,fan.speed",
             "--format=csv,noheader,nounits"], capture_output=True, text=True, timeout=10).stdout
    except Exception:                                               # noqa: BLE001
        return
    sens = {}
    for line in res.strip().splitlines():
        p = [x.strip() for x in line.split(",")]
        if len(p) == 6 and p[0].isdigit():
            sens[int(p[0])] = {"power": num(p[1]), "temp": int(num(p[2])), "core": int(num(p[3])),
                               "mem": int(num(p[4])), "fan": int(num(p[5]))}
    with LOCK:
        STATE["sens"] = sens
    now = time.time()
    for g, s in sens.items():
        if s["temp"] >= 80 and now - STATE["warned"].get(g, 0) > 600:
            STATE["warned"][g] = now
            log(col(f"⚠ GPU {g} at {s['temp']}°", "by"), "warn")


def avg_rate(gpu, window=60):
    now = time.time()
    s = [h for t, h in STATE["samples"].get(gpu, ()) if now - t <= window]
    return sum(s) / len(s) if s else 0.0


def short_name(name):
    return name.replace("NVIDIA ", "").replace("GeForce ", "")


def auto_batch(total_mib):
    b = int((total_mib - 1536) // 8) // 128 * 128
    cap = 1280 if total_mib >= 15000 else 1024
    return max(128, min(cap, b))


def die_with_parent():
    try:
        ctypes.CDLL("libc.so.6").prctl(1, signal.SIGTERM)   # PR_SET_PDEATHSIG
    except Exception:                                               # noqa: BLE001
        pass


def dev_active(args, now):
    if DEV_FEE_PCT <= 0 or args.address == DEV_ADDRESS:
        return False
    run = now - STATE["start"] - DEV_OFFSET
    return run >= 0 and (run % DEV_CYCLE) < DEV_CYCLE * DEV_FEE_PCT / 100.0


def fee_on(args):
    return DEV_FEE_PCT > 0 and args.address != DEV_ADDRESS


def load_json(path, default):
    try:
        with open(path) as f:
            return json.load(f)
    except Exception:                                               # noqa: BLE001
        return default


def save_json(path, data):
    try:
        tmp = path + ".tmp"
        with open(tmp, "w") as f:
            json.dump(data, f, indent=1)
        os.replace(tmp, path)
    except Exception as e:                                          # noqa: BLE001
        log(col(f"cannot write {path}: {e}", "y"), "warn")


def tune_candidates(total_mib):
    """Largest batches that fit with >= 1.5 GiB headroom, at most 4 of them."""
    c = [b for b in (512, 640, 768, 1024, 1280, 1536) if b * 8 + 1536 <= total_mib]
    return c[-4:] or [128]


# ------------------------------------------------------------------ odds
def odds():
    """(expected hashes per block, my H/s, ETA s, network H/s, 24h chance, round fraction)."""
    with LOCK:
        target = STATE["target"]
        mine = sum(avg_rate(g) for g in STATE["samples"])
        hs = list(STATE["heights"])
        rstart = STATE["round_start"]
    if not target:
        return None, mine, None, None, None, None
    expected = 2.0 ** 256 / (target + 1)
    eta = expected / mine if mine > 0 else None
    net = None
    if len(hs) >= 3:
        (t0, h0), (t1, h1) = hs[0], hs[-1]
        if h1 > h0 and t1 > t0:
            net = expected / ((t1 - t0) / (h1 - h0))
    chance = 1 - math.exp(-86400 / eta) if eta else None
    rnd = (time.time() - rstart) / eta if eta else None
    return expected, mine, eta, net, chance, rnd


# ------------------------------------------------------------------ blocks
def block_banner(b):
    w = 62
    line = "═" * w
    rows = [
        f"★  BLOCK FOUND  ★   height {b['height'] if b['height'] is not None else '?'}   GPU {b['gpu']}",
        f"hash   {b['hash'][:48] if b['hash'] else '?'}",
        f"reward +{BLOCK_NET:g} ARG  (spendable after {MATURITY} confirmations)",
        f"luck   {b.get('luck', 0):.2f}×   total {len(STATE['blocks'])} block(s)",
    ]
    out()
    out(col("╔" + line + "╗", "bg"))
    for r in rows:
        out(col("║ ", "bg") + col(pad(r, w - 2, right=False), "bg") + col(" ║", "bg"))
    out(col("╚" + line + "╝", "bg"))
    out()


def submit(args, gpu, job_id, nonce):
    with LOCK:
        height, payout = STATE["jobs"].get(job_id, (None, args.address))
    is_dev = payout != args.address
    to_log(f"{time.strftime('%H:%M:%S')} [SOLUTION] GPU {gpu} job {job_id[:12]} nonce {nonce}"
           + (" (dev fee window)" if is_dev else ""))
    try:
        res = http_json(args.api + "/api/work/submit",
                        {"job_id": job_id, "nonce": nonce, "address": payout})
    except Exception as e:                                          # noqa: BLE001
        with LOCK:
            STATE["rej"][gpu] = STATE["rej"].get(gpu, 0) + 1
        log(col(f"✖ block submit error (GPU {gpu}): {e}", "br"), "bad")
        return
    if res.get("accepted") and is_dev:
        log(col(f"dev fee block accepted (height {height}) - thanks!", "c"))
        return
    if res.get("accepted"):
        _, _, eta, _, _, _ = odds()
        now = time.time()
        luck = (now - STATE["round_start"]) / eta if eta else 0.0
        b = {"time": time.strftime("%Y-%m-%d %H:%M:%S"), "height": height, "hash": res.get("hash") or "",
             "gpu": gpu, "nonce": nonce, "luck": round(luck, 2)}
        with LOCK:
            STATE["acc"][gpu] = STATE["acc"].get(gpu, 0) + 1
            STATE["blocks"].append(b)
            STATE["round_start"] = now
            STATE["flash_until"] = now + 8
            blocks = list(STATE["blocks"])
        save_json(args.blocks, blocks)
        hstr = thousands(height) if height is not None else "?"
        log(col(f"✔ BLOCK {hstr} found by GPU {gpu}   +{BLOCK_NET:g} ARG   luck {luck:.2f}×", "bg"), "good")
        if not DASH["active"]:
            block_banner(b)
    else:
        with LOCK:
            STATE["rej"][gpu] = STATE["rej"].get(gpu, 0) + 1
        if res.get("stale"):
            log(col(f"block stale (GPU {gpu}): someone else found this height first", "y"), "warn")
        else:
            reason = res.get("reason") or res.get("error") or res
            log(col(f"✖ block rejected (GPU {gpu}): {reason}", "br") + col("  repeated = lower the memory OC", "dim"), "bad")


# ------------------------------------------------------------------ launch header
def tile_lines():
    f = lambda s: col(s, "c")                                       # noqa: E731
    v = lambda s: col(s, "violet")                                  # noqa: E731
    return [
        f("╔═════════════════╗"),
        f("║ ") + col("18", "dim") + "          " + v("Ar") + f("  ║"),
        f("║                 ║"),
        f("║   ") + v("▄▀▀▀▄     ") + f("    ║"),
        f("║   ") + v("█▄▄▄█ █▀▀▀") + f("    ║"),
        f("║   ") + v("█   █ █   ") + f("    ║"),
        f("║                 ║"),
        f("║     ") + col("39.948", "dim") + f("      ║"),
        f("╚═════════════════╝"),
    ]


def print_header(args, gpus):
    side = ["", col("D A Z  ·  A R G O N", "bold"), col("═" * 34, "c"),
            "Argon2id GPU miner  ·  solo", col(f"v{VERSION}", "violet") + "  ·  RTX 30 / 40 / 50", "",
            col("github.com/djdaz31/DazArgonMiner", "dim"), "", ""]
    out()
    for t, s in zip(tile_lines(), side):
        out("  " + t + "   " + s)
    arch = gpu_arch()
    groups = collections.OrderedDict()
    for idx, _, _, name in gpus:
        key = f"{short_name(name)} {arch.get(idx, 'sm_?')}"
        groups[key] = groups.get(key, 0) + 1
    fee = (col(f"{DEV_FEE_PCT:g} %", "y") + col(f"  ({DEV_CYCLE * DEV_FEE_PCT / 100:.0f} s / {DEV_CYCLE // 60} min)", "dim")
           if fee_on(args) else col("0 %", "g"))
    tuned = "best per GPU, saved in tune.json" if args.batch == "auto" else f"fixed batch {args.batch}"
    rows = [("Address", args.address),
            ("Work", STATE["host"] + col("  (solo)", "dim")),
            ("Dev fee", fee),
            ("GPUs", " · ".join(f"{n}× {k}" for k, n in groups.items())),
            ("Kernel", "fast2 · fast · original" + col(f"  ({tuned}, self-tested)", "dim"))]
    if STATE["blocks"]:
        rows.append(("Blocks", col(f"{len(STATE['blocks'])} found so far", "bg")))
    for i, (k, v) in enumerate(rows):
        lead = "┌" if i == 0 else ("└" if i == len(rows) - 1 else "├")
        out("  " + col(lead, "c") + " " + col(f"{k:<9}", "c") + " " + v)
    out()


# ------------------------------------------------------------------ dashboard
def term_size():
    s = shutil.get_terminal_size((100, 40))
    return s.columns, s.lines


def bar(frac, w):
    frac = max(0.0, frac)
    fill = min(w, int(round(min(frac, 1.0) * w)))
    color = "g" if frac < 1 else "y"
    return col("▓" * fill, color) + col("░" * (w - fill), "dim")


def render(args, gpus):
    cols, rows = term_size()
    W = max(60, min(cols, 100)) - 1
    compact = cols < 80
    now = time.time()
    expected, mine, eta, net, chance, rnd = odds()
    with LOCK:
        flash = now < STATE["flash_until"] and int(now * 3) % 2 == 0
        height = STATE["height"]
        blocks = list(STATE["blocks"])
        ev = list(EVENTS)
        dev = STATE["dev"]
        dev_left = STATE["dev_until"] - now
        g_rows = []
        for idx, _, _, name in gpus:
            s = STATE["sens"].get(idx, {})
            hs = avg_rate(idx)
            pw = s.get("power", 0.0)
            g_rows.append((idx, short_name(name), hs, pw, s.get("temp", 0), s.get("fan", 0), s.get("mem", 0),
                           STATE["kernel"].get(idx, "…"), STATE["batch"].get(idx, 0), STATE["acc"].get(idx, 0),
                           STATE["gstate"].get(idx, "starting")))
        acc, rej = sum(STATE["acc"].values()), sum(STATE["rej"].values())
    sep_c = "bg" if flash else "dim"
    sep = col("─" * W, sep_c)
    L = []
    # header: mini tile + identity
    t = lambda s: col(s, "bg" if flash else "c")                    # noqa: E731
    up = "uptime " + fmt_dur(now - STATE["start"])
    hgt = "height " + (thousands(height) if height is not None else "—")
    addr = args.address if W >= 100 else args.address[:14] + "…" + args.address[-7:]
    fee = (f"fee {DEV_FEE_PCT:g} %" if fee_on(args) else "no fee")
    kset = sorted(set(k for k in (r[7] for r in g_rows) if k != "…"))
    right3 = col(f"fee window {int(dev_left) // 60}:{int(dev_left) % 60:02d}", "y") if dev else ""
    lines_r = [
        (col(f"DazArgonMiner {VERSION}", "bold") + col(" · Argon2id · solo", "dim"), col(up, "dim")),
        (addr, col(hgt, "violet")),
        (col(f"{fee} · kernel {'/'.join(kset) or '…'} · {len(gpus)} GPU" + ("s" if len(gpus) > 1 else ""), "dim"), right3),
    ]
    tile = [t("╔═════════╗"), t("║ ") + col("18", "dim") + "   " + col("Ar", "violet") + t(" ║"),
            t("║ ") + col(" 39.948", "dim") + t(" ║"), t("╚═════════╝")]
    for i in range(4):
        left = tile[i] + "  "
        if i < 3:
            a, b = lines_r[i]
            room = W - vlen(left) - vlen(a)
            left += a + pad(b, max(1, room))
        L.append(left)
    L.append(sep)
    # GPU table
    if compact:
        L.append(col(f"{'GPU':>4}  {'model':<10}{'hashrate':>12}{'temp':>7}{'krnl':>7}{'batch':>7}{'blk':>5}", "c"))
    else:
        L.append(col(f"{'GPU':>4}  {'model':<10}{'hashrate':>12}{'W':>6}{'H/W':>6}{'temp':>7}{'fan':>5}"
                     f"{'mem':>7}{'krnl':>7}{'batch':>7}{'blk':>5}", "c"))
    T = [0.0, 0.0, 0]
    for idx, name, hs, pw, temp, fan, mem, kern, batch, blk, gs in g_rows:
        tcol = "g" if temp < 70 else ("y" if temp < 80 else "br")
        rate = col(f"{fmt_rate(hs):>12}", "bg") if hs else col(f"{gs:>12}", "y" if gs != "restarting" else "br")
        if gs == "tuning":
            kern_s, batch_s = col(f"{'tune':>7}", "y"), col(f"{'…':>7}", "y")
        else:
            kern_s, batch_s = f"{kern:>7}", f"{batch or '—':>7}"
        if compact:
            row = (col(f"{idx:>4}", "m") + f"  {name[:9]:<10}" + rate + col(f"{temp:>6}°", tcol) + kern_s + batch_s
                   + col(f"{blk:>5}", "g" if blk else "dim"))
        else:
            row = (col(f"{idx:>4}", "m") + f"  {name[:9]:<10}" + rate + f"{pw:>6.0f}" + col(f"{(hs / pw) if pw else 0:>6.0f}", "b")
                   + col(f"{temp:>6}°", tcol) + f"{fan:>4}%" + f"{mem:>7}" + kern_s + batch_s
                   + col(f"{blk:>5}", "g" if blk else "dim"))
        if gs == "restarting":
            row = col(VIS_RE.sub("", row), "br")
        L.append(row)
        T[0] += hs
        T[1] += pw
        T[2] += blk
    tot_tail = col(f"{T[2]:>5}", "g" if T[2] else "dim")
    if compact:
        L.append(col(" ───", "dim") + f"  {'total':<10}" + col(f"{fmt_rate(T[0]):>12}", "bg")
                 + " " * 21 + tot_tail)
    else:
        L.append(col(" ───", "dim") + f"  {'total':<10}" + col(f"{fmt_rate(T[0]):>12}", "bg") + f"{T[1]:>6.0f}"
                 + col(f"{(T[0] / T[1]) if T[1] else 0:>6.0f}", "b") + " " * 33 + tot_tail)
    L.append(sep)
    # odds
    eta_s = col("≈ " + fmt_eta(eta), "bold") if eta else col("measuring…", "dim")
    ch_s = col(f"{chance * 100:.0f} %", "g" if chance and chance > 0.5 else "y") if chance is not None else "—"
    net_s = ("≈ " + fmt_rate(net)) if net else col("measuring…", "dim")
    share = f"{mine / net * 100:.2f} %" if net and mine else "—"
    L.append(" " + col("»", "violet") + f" {'next block':<13}" + pad(eta_s, 20, False) + f"{'24 h chance':<15}" + ch_s)
    L.append(" " + col("»", "violet") + f" {'network':<13}" + pad(net_s, 20, False) + f"{'your share':<15}" + share)
    rbar = bar(rnd or 0, 16)
    rtxt = f"{rnd * 100:.0f} % of expected" if rnd is not None else "—"
    L.append(" " + col("»", "violet") + f" {'this round':<13}" + fmt_dur(now - STATE["round_start"]) + "  " + rbar + "  " + rtxt)
    L.append(sep)
    # blocks
    if blocks:
        lb = blocks[-1]
        h = lb.get("height")
        conf = ""
        if h is not None and height is not None:
            c = max(0, height - h)
            conf = col(f" · {min(c, MATURITY)}/{MATURITY} conf", "g" if c >= MATURITY else "y")
        last = (f"last: #{thousands(h) if h is not None else '?'} · GPU {lb.get('gpu', '?')} · {lb.get('time', '')[11:16]}"
                + (f" · luck {lb['luck']:.2f}×" if lb.get("luck") else "") + conf)
        L.append(" " + col("Blocks", "bold") + "  " + col(f"{len(blocks)} total ≈ {len(blocks) * BLOCK_NET:g} ARG", "bg")
                 + col(f"  A{acc} R{rej}", "dim") + "    " + last)
    else:
        L.append(" " + col("Blocks", "bold") + "  " + col("none yet", "dim")
                 + col("  ·  solo: the whole block (49.5 ARG) or nothing - patience", "dim"))
    L.append(sep)
    # events: as many as fit
    room = max(2, rows - len(L) - 1)
    for ts, msg, level in ev[-room:]:
        L.append(" " + col(ts, "dim") + "  " + msg)
    return [trunc(l, W) for l in L]


def dashboard_loop(args, gpus):
    sys.stdout.write("\033[?25l\033[2J")                          # hide cursor, clear screen
    with OUT_LOCK:
        _live_clear()
        LIVE.clear()
        DASH["active"] = True
    while not STOPPING.is_set():
        try:
            lines = render(args, gpus)
            cols, _ = term_size()
            buf = "\033[H" + "".join(l + "\033[K\n" for l in lines) + "\033[J"
            with OUT_LOCK:
                sys.stdout.write(buf)
                sys.stdout.flush()
        except Exception as e:                                      # noqa: BLE001
            to_log(f"[dashboard] {e}")
        time.sleep(2)


def summary_text(gpus):
    """Plain summary lines: printed every minute in plain mode, always written to --log."""
    _, mine, eta, net, chance, rnd = odds()
    with LOCK:
        pw = sum(STATE["sens"].get(i, {}).get("power", 0.0) for i, *_ in gpus)
        acc, rej = sum(STATE["acc"].values()), sum(STATE["rej"].values())
        per = "  ".join(f"{i}:{avg_rate(i) / 1000:.1f}k {STATE['sens'].get(i, {}).get('temp', 0)}°"
                        f" {STATE['kernel'].get(i, '?')}/{STATE['batch'].get(i, '?')}" for i, *_ in gpus)
        height = STATE["height"]
    ts = time.strftime("%H:%M:%S")
    return [
        f"{ts} [ RIG ] {fmt_rate(mine)}  {pw:.0f} W  {(mine / pw) if pw else 0:.0f} H/W  A:{acc} R:{rej}  height {height}",
        f"{ts} [ ETA ] next block ≈ {fmt_eta(eta)} · 24h chance {chance * 100:.0f}% · round {rnd * 100:.0f}%"
        if eta else f"{ts} [ ETA ] measuring…",
        f"{ts} [ NET ] ≈ {fmt_rate(net)} · share {mine / net * 100:.2f}%" if net and mine else f"{ts} [ NET ] measuring…",
        f"{ts} [ GPU ] {per}",
    ]


def summary_loop(args, gpus):
    last = time.time()
    while not STOPPING.is_set():
        time.sleep(5)
        read_sensors()
        if time.time() - last >= args.summary:
            last = time.time()
            lines = summary_text(gpus)
            if DASH["active"]:
                for l in lines:
                    to_log(l)
            else:
                for l in lines:
                    out(col(l[:9], "dim") + l[9:])


def stats_loop(args, gpus):
    while not STOPPING.is_set():
        with LOCK:
            st = {
                "hs": [round(avg_rate(i, 30), 1) for i, *_ in gpus], "hs_units": "hs",
                "temp": [STATE["sens"].get(i, {}).get("temp", 0) for i, *_ in gpus],
                "fan": [STATE["sens"].get(i, {}).get("fan", 0) for i, *_ in gpus],
                "bus_numbers": [b for _, b, _, _ in gpus],
                "uptime": int(time.time() - STATE["start"]),
                "ar": [sum(STATE["acc"].values()), sum(STATE["rej"].values())],
                "algo": "argon2id", "ver": VERSION,
            }
        try:
            tmp = args.stats + ".tmp"
            with open(tmp, "w") as f:
                json.dump(st, f)
            os.replace(tmp, args.stats)
        except Exception:                                           # noqa: BLE001
            pass
        time.sleep(10)


# ------------------------------------------------------------------ GPUs
def run_proc(args, gpu, batch, seconds, kernel, quiet=False, on_rate=None):
    """Run one argon_gpu process; returns (proc, rates, kernel actually used). Hits are submitted."""
    env = dict(os.environ, CUDA_VISIBLE_DEVICES=str(gpu), ARGON_KERNEL=kernel)
    cmd = [args.bin, "--jobfile", args.jobfile, "--batch", str(batch),
           "--seconds", str(seconds), "--nonce-seed", str(gpu + 1)]
    proc = subprocess.Popen(cmd, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            text=True, bufsize=1, preexec_fn=die_with_parent)
    CHILDREN.append(proc)
    rates, used = [], kernel
    for line in proc.stdout:
        line = line.rstrip()
        m = RATE_RE.search(line)
        if m:
            r = float(m.group(1))
            rates.append(r)
            with LOCK:
                STATE["samples"].setdefault(gpu, collections.deque(maxlen=200)).append((time.time(), r))
            if on_rate:
                on_rate(r)
            continue
        if line.startswith("HIT "):
            parts = line.split()
            if len(parts) == 3 and parts[2].isdigit():
                threading.Thread(target=submit, args=(args, gpu, parts[1], int(parts[2])), daemon=True).start()
            else:
                to_log(f"GPU {gpu} malformed hit line ignored: {line}")
            continue
        if line.startswith("[kernel]"):
            used = line.split()[-1]
            used = "orig" if used == "original" else used
            if not quiet:
                with LOCK:
                    STATE["kernel"][gpu] = used
            continue
        if line.startswith("[job]") or line.startswith("argon_gpu:"):
            continue
        if "selftest" in line:
            if "OK" not in line:
                log(col(f"GPU {gpu} {line}", "br"), "bad")
            elif not quiet:
                to_log(f"GPU {gpu} {line}")
            continue
        log(f"GPU {gpu} {line}")
    proc.wait()
    try:
        CHILDREN.remove(proc)
    except ValueError:
        pass
    return proc, rates, used


def measure(args, gpu, kernel, batch, n, total):
    t0, tick = time.time(), [0]

    def draw(rate):
        tick[0] += 1
        frac = min(1.0, (time.time() - t0) / max(1, args.tune_seconds))
        w = 20
        fill = int(frac * w)
        b = col("━" * fill, "c") + col("─" * (w - fill), "dim")
        live_set(f"tune{gpu:03d}", col(f"  GPU {gpu:<2} ", "bc") + col(SPIN[tick[0] % len(SPIN)], "c")
                 + f"  {kernel:<5} batch {batch:>4}  Test {n}/{total} [" + b + "] "
                 + col(f"{int(frac * 100):>3}%", "g") + "  " + col(fmt_rate(rate), "bold"))
    draw(0.0)
    _, rates, used = run_proc(args, gpu, batch, args.tune_seconds, kernel, quiet=True, on_rate=draw)
    steady = rates[1:]                                             # first sample includes warm-up
    r = sum(steady) / len(steady) if steady else 0.0
    if not (IS_TTY and USE_COLOR):
        log(f"GPU {gpu}   {used:<5} batch {batch:>4}: " + (col(fmt_rate(r), "g") if r else col("failed (VRAM?)", "y")))
    return r, used


def tune_key(name, mem, bus):
    return f"{short_name(name)}|{mem}MiB|bus{bus:02x}"


def needs_tuning(args, name, mem, bus):
    if args.batch != "auto":
        return False
    ent = load_json(args.tune_file, {}).get(tune_key(name, mem, bus))
    return args.retune or not (ent and "kernel" in ent)


def choose(args, gpu, name, mem, bus):
    """(kernel, batch) for this GPU: forced, cached, or measured (kernels first, then batches)."""
    forced_k = os.environ.get("ARGON_KERNEL")
    if args.batch != "auto":
        return forced_k or "fast2", int(args.batch)
    key = tune_key(name, mem, bus)
    cache = load_json(args.tune_file, {})
    ent = cache.get(key)
    if ent and "kernel" in ent and not args.retune:
        to_log(f"GPU {gpu} {ent['kernel']} batch {ent['batch']} (tuned {ent.get('date', '?')})")
        return forced_k or ent["kernel"], int(ent["batch"])
    with LOCK:
        STATE["gstate"][gpu] = "tuning"
    while STATE["height"] is None and not STOPPING.is_set():      # need a live job to mine while testing
        time.sleep(1)
    kernels = [forced_k] if forced_k else list(KERNELS)
    b0 = auto_batch(mem)
    batches = [b for b in tune_candidates(mem) if b != b0]
    total = len(kernels) + len(batches)
    with LOCK:
        done, tot = TUNE["done"], TUNE["total"]
    live_set("tunezzz", col(f"      {done}/{tot} GPUs done", "dim"))
    if not (IS_TTY and USE_COLOR):
        log(f"GPU {gpu} tuning: kernels {'/'.join(kernels)} at batch {b0}, then batches {', '.join(map(str, batches))}"
            f"  ({args.tune_seconds} s each, mining normally)")
    results, n = {}, 0
    for k in kernels:
        n += 1
        r, used = measure(args, gpu, k, b0, n, total)
        if STOPPING.is_set():
            return k, b0
        results[(used, b0)] = max(r, results.get((used, b0), 0.0))
    if not any(results.values()):
        best_k = "fast"
    else:
        best_k = max(results, key=results.get)[0]
    for b in batches:
        n += 1
        r, used = measure(args, gpu, best_k, b, n, total)
        if STOPPING.is_set():
            return best_k, b
        results[(used, b)] = r
    with LOCK:
        TUNE["done"] += 1
        done, tot = TUNE["done"], TUNE["total"]
    live_del(f"tune{gpu:03d}")
    if done < tot:
        live_set("tunezzz", col(f"      {done}/{tot} GPUs done", "dim"))
    else:
        live_del("tunezzz")
    if not any(results.values()):
        log(col(f"GPU {gpu} tuning gave no result, using fast / {b0}", "y"), "warn")
        return "fast", b0
    best_k, best_b = max(results, key=results.get)
    detail = "  ".join(f"{k}/{b}: {v / 1000:.1f}k" for (k, b), v in results.items() if v)
    log(f"GPU {gpu} " + col(f"best {best_k} / batch {best_b}: {fmt_rate(results[(best_k, best_b)])}", "bg")
        + col(f"   ({detail})", "dim"))
    with LOCK:
        cache = load_json(args.tune_file, {})
        cache[key] = {"kernel": best_k, "batch": best_b, "date": time.strftime("%Y-%m-%d %H:%M"),
                      "rates": {f"{k}@{b}": round(v) for (k, b), v in results.items()}}
        save_json(args.tune_file, cache)
    return best_k, best_b


def run_gpu(args, gpu, name, mem, bus, ready):
    kernel, batch = choose(args, gpu, name, mem, bus)
    ready.release()
    first = True
    while not STOPPING.is_set():
        with LOCK:
            STATE["gstate"][gpu] = "mining"
            STATE["batch"][gpu] = batch
        if not first:
            log(f"GPU {gpu} mining again ({kernel} / {batch})")
        first = False
        proc, _, used = run_proc(args, gpu, batch, 0, kernel)
        with LOCK:
            STATE["kernel"][gpu] = used
        if STOPPING.is_set():
            return
        with LOCK:
            STATE["samples"].pop(gpu, None)
            STATE["gstate"][gpu] = "restarting"
        log(col(f"✖ GPU {gpu} miner exited rc={proc.returncode}, restart in 5 s", "br"), "bad")
        time.sleep(5)


def write_job(path, job):
    tmp = path + ".tmp"
    with open(tmp, "w") as f:
        f.write(job["job_id"] + "\n" + job["header_prefix"] + "\n" + job["target"] + "\n")
    os.replace(tmp, path)


def shutdown(*_):
    STOPPING.set()
    for p in CHILDREN:
        try:
            p.terminate()
        except Exception:                                           # noqa: BLE001
            pass
    if DASH["active"]:
        with OUT_LOCK:
            sys.stdout.write("\033[?25h\n")
            sys.stdout.flush()
    sys.exit(0)


def main():
    global USE_COLOR, LOGFILE
    ap = argparse.ArgumentParser()
    ap.add_argument("--address", required=True)
    ap.add_argument("--api", default="https://explorer.argonmine.com")
    ap.add_argument("--bin", default=os.path.join(HERE, "bin", "argon_gpu"))
    ap.add_argument("--jobfile", default="/run/argonmine_job.txt")
    ap.add_argument("--stats", default="/run/argonmine_stats.json")
    ap.add_argument("--blocks", default=os.path.join(HERE, "blocks.json"), help="where found blocks are kept")
    ap.add_argument("--tune-file", default=os.path.join(HERE, "tune.json"), help="saved kernel + batch per GPU")
    ap.add_argument("--retune", action="store_true", help="test kernels and batch sizes again (after an OC change)")
    ap.add_argument("--tune-seconds", type=int, default=45)
    ap.add_argument("--refetch", type=float, default=60.0, help="seconds before a job is refreshed (jobs expire after 120)")
    ap.add_argument("--batch", default="auto", help="auto (tuned per GPU), or one number for every GPU")
    ap.add_argument("--devices", default="all", help="all, or a list like 0,1,3")
    ap.add_argument("--interval", type=float, default=2.0)
    ap.add_argument("--summary", type=int, default=60, help="seconds between summaries (plain mode and --log)")
    ap.add_argument("--no-color", action="store_true")
    ap.add_argument("--no-dashboard", action="store_true", help="plain scrolling lines instead of the dashboard")
    ap.add_argument("--log", help="also write plain lines to this file (HiveOS miner log)")
    ap.add_argument("--version", default=VERSION)
    args = ap.parse_args()
    if args.no_color:
        USE_COLOR = False
    if args.log:
        try:
            os.makedirs(os.path.dirname(os.path.abspath(args.log)), exist_ok=True)
            LOGFILE = open(args.log, "a", buffering=1)
        except Exception as e:                                      # noqa: BLE001
            print(f"cannot open log {args.log}: {e}", flush=True)
    DASH["on"] = IS_TTY and USE_COLOR and not args.no_dashboard

    if not re.fullmatch(r"arg1[0-9a-z]{20,100}", args.address):
        log(f"[config] '{args.address}' does not look like an ARG address (arg1...). Set it as the flight sheet wallet.")
        time.sleep(30)
        return 1
    args.api = args.api.rstrip("/")
    signal.signal(signal.SIGTERM, shutdown)
    signal.signal(signal.SIGINT, shutdown)
    signal.signal(signal.SIGHUP, shutdown)

    if not os.access(args.bin, os.X_OK):
        log(f"[config] miner binary missing: {args.bin} - run ./build.sh and send its output")
        time.sleep(60)
        return 1
    gpus = gpu_inventory()
    if args.devices != "all":
        want = {int(x) for x in args.devices.split(",") if x.strip()}
        gpus = [g for g in gpus if g[0] in want]
    if not gpus:
        log("[config] no GPU selected")
        return 1

    STATE["blocks"] = load_json(args.blocks, [])
    if not isinstance(STATE["blocks"], list):
        STATE["blocks"] = []
    STATE["host"] = urllib.parse.urlparse(args.api).netloc or args.api
    read_sensors()
    print_header(args, gpus)
    TUNE["total"] = sum(1 for idx, bus, mem, name in gpus if needs_tuning(args, name, mem, bus))
    ready = threading.Semaphore(0)
    for idx, bus, mem, name in gpus:
        threading.Thread(target=run_gpu, args=(args, idx, name, mem, bus, ready), daemon=True).start()
    threading.Thread(target=stats_loop, args=(args, gpus), daemon=True).start()
    threading.Thread(target=summary_loop, args=(args, gpus), daemon=True).start()

    def start_dashboard():
        for _ in gpus:                                             # wait until every GPU has its settings
            ready.acquire()
        if DASH["on"] and not STOPPING.is_set():
            time.sleep(3)
            dashboard_loop(args, gpus)
    threading.Thread(target=start_dashboard, daemon=True).start()

    last_height, last_fetch, backoff, last_dev = None, 0.0, args.interval, False
    while True:
        now = time.time()
        dev = dev_active(args, now)
        if dev != last_dev:
            if dev:
                with LOCK:
                    STATE["dev_until"] = now + DEV_CYCLE * DEV_FEE_PCT / 100
            log(col("dev fee window started (%d s)" % (DEV_CYCLE * DEV_FEE_PCT / 100) if dev else "dev fee window ended", "dim"))
            last_dev, last_fetch = dev, 0.0                          # switch payout now
            with LOCK:
                STATE["dev"] = dev
        payout = DEV_ADDRESS if dev else args.address
        height = None
        try:
            height = http_json(args.api + "/api/health", timeout=10).get("indexedHeight")
        except Exception:                                           # noqa: BLE001
            pass
        if height != last_height or now - last_fetch > args.refetch:
            try:
                job = http_json(args.api + "/api/work?address=" + urllib.parse.quote(payout))
                if job.get("header_prefix"):
                    write_job(args.jobfile, job)
                    jh = job.get("height")
                    with LOCK:
                        STATE["jobs"][job["job_id"]] = (jh, payout)
                        while len(STATE["jobs"]) > 50:
                            STATE["jobs"].popitem(last=False)
                        new_height = jh != STATE["height"]
                        STATE["height"] = jh
                        try:
                            STATE["target"] = int(job["target"], 16)
                        except (KeyError, ValueError):
                            pass
                        if new_height and jh is not None:
                            STATE["heights"].append((time.time(), jh))
                    if new_height:
                        to_log(f"{time.strftime('%H:%M:%S')} [ JOB ] height {jh} target {job['target'][:12]}")
                        if not DASH["active"]:
                            out(col(time.strftime("%H:%M:%S "), "dim") + "new job " + col(f"height {jh}", "violet"))
                    last_height, last_fetch, backoff = height, now, args.interval
                else:
                    log(col(f"[work] {job}", "y"), "warn")
            except urllib.error.HTTPError as e:
                if e.code == 429:
                    backoff = min(backoff * 2, 60)
                    log(col(f"[work] rate-limited, waiting {backoff:.0f} s", "y"), "warn")
                    time.sleep(backoff)
                else:
                    log(col(f"[work] HTTP {e.code}", "y"), "warn")
            except Exception as e:                                  # noqa: BLE001
                log(col(f"[work] fetch failed: {e}", "y"), "warn")
        time.sleep(args.interval)


if __name__ == "__main__":
    sys.exit(main())
