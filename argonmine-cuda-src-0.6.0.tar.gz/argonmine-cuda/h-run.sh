#!/usr/bin/env bash
cd "$(dirname "$0")"
. h-manifest.conf
[[ -s $CUSTOM_CONFIG_FILENAME ]] || ./h-config.sh
. "$CUSTOM_CONFIG_FILENAME"
LOG="${CUSTOM_LOG_BASENAME}.log"
mkdir -p "$(dirname "$CUSTOM_LOG_BASENAME")"
# prebuilt package: bin/argon_gpu is bundled. Rebuild only if it cannot run here (e.g. older glibc).
if [[ -x bin/argon_gpu ]] && ! grep -q usage <<<"$(bin/argon_gpu 2>&1 || true)"; then
  echo "[run] bundled binary does not run on this system: $(bin/argon_gpu 2>&1 | head -1) - rebuilding" | tee -a "$LOG"
  mv -f bin/argon_gpu bin/argon_gpu.bundled
fi
if [[ ! -x bin/argon_gpu ]]; then
  ./build.sh 2>&1 | tee -a "$LOG"
  if [[ ${PIPESTATUS[0]} -ne 0 || ! -x bin/argon_gpu ]]; then
    echo "[run] build failed - miner not started. Send the [build]/[fetch] lines above." | tee -a "$LOG"
    sleep 300; exit 1
  fi
fi
[[ -n ${KERNEL:-} ]] && export ARGON_KERNEL=$KERNEL
python3 -u argonmine_hive.py --address "$ADDRESS" --api "$API" --batch "$BATCH" \
  --devices "$DEVICES" --version "$CUSTOM_VERSION" --tune-seconds "${TUNE:-45}" ${RETUNE:+--retune} \
  --log "$LOG" 2>>"$LOG"
