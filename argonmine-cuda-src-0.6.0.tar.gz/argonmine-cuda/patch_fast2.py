#!/usr/bin/env python3
"""fast2 kernel patch for argon_gpu.cu (idempotent). Apply after patch_fast.py.

fast2 = fast (warp per hash) plus:
  * the P permutation runs in registers: rows and columns exchange data with warp shuffles,
    shared memory is only used for the two row<->column transposes (padded, fewer bank conflicts);
  * blocks are loaded/stored in "row layout" (each lane owns 4 qwords of one row): every 32-byte
    sector is still read exactly once;
  * reference blocks are read with ld.global.cg (L2 only, no L1 pollution);
  * in the data-independent half (slices 0-1) the next reference block is prefetched while the
    current block is being computed, hiding DRAM latency.
Kernel choice at run time: ARGON_KERNEL=fast2 (default) | fast | orig. Each GPU self-tests the
chosen kernel and falls back fast2 -> fast -> orig on a mismatch. "[kernel] <name>" is printed.
Usage: python3 patch_fast2.py path/to/argon_gpu.cu
"""
import sys

p = sys.argv[1]
s = open(p).read()
if "fill_kernel_w2" in s:
    print("[patch] fast2 kernel already applied")
    sys.exit(0)
if "fill_kernel_w" not in s:
    sys.exit("[patch] apply patch_fast.py first")

KERNEL = r'''
// ------------------------------------- fast2 fill kernel (registers + shuffles + prefetch)
#define FULLMASK 0xffffffffu
// row layout: lane = 4g + j owns qwords 16g + 4m + j (m = 0..3) -> one 32 B sector per row group
__device__ __forceinline__ int q_row(int lane, int m) { return 16 * (lane >> 2) + 4 * m + (lane & 3); }
// column layout: lane = 4c + j owns element p = 4m + j of column c -> qword 2c + 16(p>>1) + (p&1)
__device__ __forceinline__ int q_col(int lane, int m) {
    const int j = lane & 3;
    return 2 * (lane >> 2) + 32 * m + 16 * (j >> 1) + (j & 1);
}
__device__ __forceinline__ int padq(int q) { return q + 4 * (q >> 4); }   // shared-memory padding
__device__ __forceinline__ uint64_t ldcg64(const uint64_t *p) {
    return (uint64_t)__ldcg((const unsigned long long *)p);
}
// one BLAKE2b-style round over 4-qword groups: column step, then diagonal step via shuffles
__device__ __forceinline__ void round_r(uint64_t r[4], int s1, int s2, int s3) {
    gW(r[0], r[1], r[2], r[3]);
    r[1] = __shfl_sync(FULLMASK, r[1], s1);
    r[2] = __shfl_sync(FULLMASK, r[2], s2);
    r[3] = __shfl_sync(FULLMASK, r[3], s3);
    gW(r[0], r[1], r[2], r[3]);
    r[1] = __shfl_sync(FULLMASK, r[1], s3);
    r[2] = __shfl_sync(FULLMASK, r[2], s2);
    r[3] = __shfl_sync(FULLMASK, r[3], s1);
}
// r[m] = qword q_row(lane, m) of the block; returns P(block) in the same layout
__device__ __forceinline__ void perm_r(uint64_t r[4], uint64_t *S, int lane) {
    const int base = lane & ~3, j = lane & 3;
    const int s1 = base | ((j + 1) & 3), s2 = base | ((j + 2) & 3), s3 = base | ((j + 3) & 3);
    round_r(r, s1, s2, s3);                                   // 8 rows
    __syncwarp();
#pragma unroll
    for (int m = 0; m < 4; m++) S[padq(q_row(lane, m))] = r[m];
    __syncwarp();
#pragma unroll
    for (int m = 0; m < 4; m++) r[m] = S[padq(q_col(lane, m))];
    round_r(r, s1, s2, s3);                                   // 8 columns
#pragma unroll
    for (int m = 0; m < 4; m++) S[padq(q_col(lane, m))] = r[m];
    __syncwarp();
#pragma unroll
    for (int m = 0; m < 4; m++) r[m] = S[padq(q_row(lane, m))];
}

__global__ void __launch_bounds__(128) fill_kernel_w2(uint64_t *mem, int hashes) {
    const int lane = threadIdx.x & 31, w = threadIdx.x >> 5;
    const int hid = blockIdx.x * 4 + w;
    __shared__ uint64_t SH2[4][160], AD2[4][128];
    if (hid >= hashes) return;                  // whole warp leaves; no block-wide barriers below
    uint64_t *S = SH2[w], *AD = AD2[w];
    uint64_t *B = mem + (size_t)hid * 1048576ULL;
    int qo[4];
#pragma unroll
    for (int m = 0; m < 4; m++) qo[m] = q_row(lane, m);
    uint64_t prev[4], X[4], R[4], NX[4];
#pragma unroll
    for (int m = 0; m < 4; m++) prev[m] = B[128 + qo[m]];    // block 1
    bool have_next = false;

    for (int slice = 0; slice < 4; slice++) {
        const int indie = (slice < 2);
        const int start = (slice == 0) ? 2 : 0;
        uint64_t ctr = 0;
        for (int i = start; i < 2048; i++) {
            if (indie && (i == start || (i & 127) == 0)) {
                ctr++;
#pragma unroll
                for (int m = 0; m < 4; m++) {
                    const int q = qo[m];
                    X[m] = (q == 2) ? (uint64_t)slice : (q == 3) ? 8192ULL : (q == 4) ? 1ULL
                         : (q == 5) ? 2ULL : (q == 6) ? ctr : 0ULL;
                    R[m] = X[m];
                }
                perm_r(X, S, lane);
#pragma unroll
                for (int m = 0; m < 4; m++) { X[m] ^= R[m]; R[m] = X[m]; }
                perm_r(X, S, lane);
#pragma unroll
                for (int m = 0; m < 4; m++) AD[qo[m]] = X[m] ^ R[m];
                __syncwarp();
                have_next = false;
            }
            const uint32_t abs_idx = (uint32_t)slice * 2048u + (uint32_t)i;
            uint64_t cur[4];
            if (have_next) {
#pragma unroll
                for (int m = 0; m < 4; m++) cur[m] = NX[m];
            } else {
                const uint64_t p0 = __shfl_sync(FULLMASK, prev[0], 0);
                const uint32_t pr = indie ? (uint32_t)AD[i & 127] : (uint32_t)p0;
                const uint64_t *rb = B + (size_t)index_alpha((uint32_t)slice, (uint32_t)i, pr) * 128;
#pragma unroll
                for (int m = 0; m < 4; m++) cur[m] = ldcg64(rb + qo[m]);
            }
            // prefetch the next reference block (its index only depends on the address block)
            have_next = false;
            if (indie && i + 1 < 2048 && ((i + 1) & 127) != 0) {
                const uint32_t nref = index_alpha((uint32_t)slice, (uint32_t)(i + 1), (uint32_t)AD[(i + 1) & 127]);
                const uint64_t *nb = B + (size_t)nref * 128;       // nref < abs_idx: already written
#pragma unroll
                for (int m = 0; m < 4; m++) NX[m] = ldcg64(nb + qo[m]);
                have_next = true;
            }
#pragma unroll
            for (int m = 0; m < 4; m++) { R[m] = prev[m] ^ cur[m]; X[m] = R[m]; }
            perm_r(X, S, lane);
            uint64_t *cb = B + (size_t)abs_idx * 128;
#pragma unroll
            for (int m = 0; m < 4; m++) { X[m] ^= R[m]; cb[qo[m]] = X[m]; prev[m] = X[m]; }
            __syncwarp();                           // later reads of this block by other lanes
        }
    }
}
'''

anchor_k = "// ------------------------------------------------------------- finalize kernel"
old_sig = "static int run_selftest(int fast, uint8_t *d_hdr, uint8_t *d_mem, unsigned long long *d_hit, uint8_t *d_tag0) {"
old_launch_st = """    if (fast) fill_kernel_w<<<1, 128>>>((uint64_t *)d_mem, 1);
    else      fill_kernel<<<1, 128>>>((uint64_t *)d_mem, 1, 0);"""
old_print = '''    printf("[selftest] %s kernel: %s\\n", fast ? "fast" : "original", ok ? "OK" : "MISMATCH");'''
old_main = '''    int use_fast = !(getenv("ARGON_KERNEL") && !strcmp(getenv("ARGON_KERNEL"), "orig"));
    if (selftest_only) {
        int a = run_selftest(1, d_hdr, d_mem, d_hit, d_tag0), b = run_selftest(0, d_hdr, d_mem, d_hit, d_tag0);
        return (a && b) ? 0 : 3;
    }
    if (use_fast && !run_selftest(1, d_hdr, d_mem, d_hit, d_tag0)) {
        printf("[selftest] fast kernel gives wrong hashes on this GPU - falling back to the original kernel\\n");
        use_fast = 0;
    }
    if (!use_fast && !run_selftest(0, d_hdr, d_mem, d_hit, d_tag0)) {
        printf("[selftest] original kernel also wrong - refusing to mine (check overclock)\\n");
        return 4;
    }'''
old_launch = """        if (use_fast) fill_kernel_w<<<(batch + 3) / 4, 128>>>((uint64_t *)d_mem, batch);
        else          fill_kernel<<<batch, 128>>>((uint64_t *)d_mem, batch, 0);"""
for n in (anchor_k, old_sig, old_launch_st, old_print, old_main, old_launch):
    if s.count(n) != 1:
        sys.exit(f"[patch] source not recognised ({n.strip()[:50]}...), nothing changed")

s = s.replace(anchor_k, KERNEL + "\n" + anchor_k, 1)
s = s.replace(old_sig, '''static const char *KNAME[3] = {"original", "fast", "fast2"};
static void launch_fill(int kid, uint8_t *d_mem, int n) {
    if (kid == 2)      fill_kernel_w2<<<(n + 3) / 4, 128>>>((uint64_t *)d_mem, n);
    else if (kid == 1) fill_kernel_w<<<(n + 3) / 4, 128>>>((uint64_t *)d_mem, n);
    else               fill_kernel<<<n, 128>>>((uint64_t *)d_mem, n, 0);
}
static int run_selftest(int kid, uint8_t *d_hdr, uint8_t *d_mem, unsigned long long *d_hit, uint8_t *d_tag0) {''', 1)
s = s.replace(old_launch_st, "    launch_fill(kid, d_mem, 1);", 1)
s = s.replace(old_print, '''    printf("[selftest] %s kernel: %s\\n", KNAME[kid], ok ? "OK" : "MISMATCH");''', 1)
s = s.replace(old_main, '''    int kid = 2;
    const char *ek = getenv("ARGON_KERNEL");
    if (ek && !strcmp(ek, "orig")) kid = 0;
    else if (ek && !strcmp(ek, "fast")) kid = 1;
    if (selftest_only) {
        int c = run_selftest(2, d_hdr, d_mem, d_hit, d_tag0);
        int a = run_selftest(1, d_hdr, d_mem, d_hit, d_tag0), b = run_selftest(0, d_hdr, d_mem, d_hit, d_tag0);
        return (a && b && c) ? 0 : 3;
    }
    while (kid > 0 && !run_selftest(kid, d_hdr, d_mem, d_hit, d_tag0)) {
        printf("[selftest] %s kernel gives wrong hashes on this GPU - falling back to %s\\n", KNAME[kid], KNAME[kid - 1]);
        kid--;
    }
    if (kid == 0 && !run_selftest(0, d_hdr, d_mem, d_hit, d_tag0)) {
        printf("[selftest] original kernel also wrong - refusing to mine (check overclock)\\n");
        return 4;
    }
    printf("[kernel] %s\\n", KNAME[kid]);
    fflush(stdout);''', 1)
s = s.replace(old_launch, "        launch_fill(kid, d_mem, batch);", 1)
open(p, "w").write(s)
print("[patch] fast2 kernel applied")
